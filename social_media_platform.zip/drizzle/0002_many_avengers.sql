CREATE TABLE `adminLogs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`adminId` int NOT NULL,
	`action` varchar(255) NOT NULL,
	`targetType` varchar(64),
	`targetId` int,
	`details` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `adminLogs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `bannedUsers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`reason` text,
	`bannedBy` int NOT NULL,
	`bannedAt` timestamp NOT NULL DEFAULT (now()),
	`unbannedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `bannedUsers_id` PRIMARY KEY(`id`),
	CONSTRAINT `bannedUsers_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `contentFlags` (
	`id` int AUTO_INCREMENT NOT NULL,
	`contentType` enum('video','comment','message','profile') NOT NULL,
	`contentId` int NOT NULL,
	`flaggedBy` int NOT NULL,
	`reason` enum('profanity','explicit_content','harassment','spam','misinformation','other') NOT NULL,
	`description` text,
	`reviewed` int NOT NULL DEFAULT 0,
	`reviewedBy` int,
	`reviewedAt` timestamp,
	`action` enum('approved','removed','warned'),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `contentFlags_id` PRIMARY KEY(`id`)
);
