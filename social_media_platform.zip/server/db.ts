import { and, desc, eq, like, or, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, users,
  videos, InsertVideo,
  comments, InsertComment,
  likes, InsertLike,
  follows, InsertFollow,
  conversations, InsertConversation,
  messages, InsertMessage
} from "../drizzle/schema";
import { ENV } from './_core/env';
import { sendWelcomeEmail } from './email';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    const result = await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
    
    // Send welcome email for new users (when insertId exists)
    if (result[0].insertId && user.email && user.name) {
      sendWelcomeEmail(user.name, user.email).catch(err => {
        console.error('[Email] Failed to send welcome email:', err);
      });
    }
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Video queries
export async function createVideo(video: InsertVideo) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(videos).values(video);
  return result;
}

export async function getVideoById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(videos).where(eq(videos.id, id)).limit(1);
  return result[0] || null;
}

export async function getVideosByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(videos).where(eq(videos.userId, userId)).orderBy(desc(videos.createdAt));
}

export async function getAllVideos(limit = 50) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(videos).orderBy(desc(videos.createdAt)).limit(limit);
}

export async function incrementVideoViews(videoId: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(videos).set({ views: sql`${videos.views} + 1` }).where(eq(videos.id, videoId));
}

export async function searchVideos(query: string) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(videos)
    .where(or(
      like(videos.title, `%${query}%`),
      like(videos.description, `%${query}%`)
    ))
    .orderBy(desc(videos.createdAt))
    .limit(50);
}

// Comment queries
export async function createComment(comment: InsertComment) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(comments).values(comment);
}

export async function getCommentsByVideoId(videoId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(comments).where(eq(comments.videoId, videoId)).orderBy(desc(comments.createdAt));
}

// Like queries
export async function createLike(like: InsertLike) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(likes).values(like);
  await db.update(videos).set({ likes: sql`${videos.likes} + 1` }).where(eq(videos.id, like.videoId));
}

export async function removeLike(videoId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(likes).where(and(eq(likes.videoId, videoId), eq(likes.userId, userId)));
  await db.update(videos).set({ likes: sql`${videos.likes} - 1` }).where(eq(videos.id, videoId));
}

export async function getUserLike(videoId: number, userId: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(likes).where(and(eq(likes.videoId, videoId), eq(likes.userId, userId))).limit(1);
  return result[0] || null;
}

// Follow queries
export async function createFollow(follow: InsertFollow) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(follows).values(follow);
}

export async function removeFollow(followerId: number, followingId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.delete(follows).where(and(eq(follows.followerId, followerId), eq(follows.followingId, followingId)));
}

export async function getFollowers(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(follows).where(eq(follows.followingId, userId));
}

export async function getFollowing(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(follows).where(eq(follows.followerId, userId));
}

export async function isFollowing(followerId: number, followingId: number) {
  const db = await getDb();
  if (!db) return false;
  const result = await db.select().from(follows).where(and(eq(follows.followerId, followerId), eq(follows.followingId, followingId))).limit(1);
  return result.length > 0;
}

// Conversation queries
export async function getOrCreateConversation(user1Id: number, user2Id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const existing = await db.select().from(conversations)
    .where(
      or(
        and(eq(conversations.participant1Id, user1Id), eq(conversations.participant2Id, user2Id)),
        and(eq(conversations.participant1Id, user2Id), eq(conversations.participant2Id, user1Id))
      )
    )
    .limit(1);
  
  if (existing[0]) return existing[0];
  
  const result = await db.insert(conversations).values({
    participant1Id: user1Id,
    participant2Id: user2Id,
  });
  
  return await db.select().from(conversations).where(eq(conversations.id, Number(result[0].insertId))).limit(1).then(r => r[0]);
}

export async function getUserConversations(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(conversations)
    .where(or(eq(conversations.participant1Id, userId), eq(conversations.participant2Id, userId)))
    .orderBy(desc(conversations.lastMessageAt));
}

// Message queries
export async function createMessage(message: InsertMessage) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(messages).values(message);
  await db.update(conversations)
    .set({ lastMessageAt: new Date() })
    .where(eq(conversations.id, message.conversationId));
}

export async function getMessagesByConversationId(conversationId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(messages)
    .where(eq(messages.conversationId, conversationId))
    .orderBy(messages.createdAt);
}

// User search
export async function searchUsers(query: string) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(users)
    .where(or(
      like(users.name, `%${query}%`),
      like(users.email, `%${query}%`)
    ))
    .limit(20);
}
