/**
 * Friends System Database Helpers
 * Handles friend requests, friends list, and blocking
 */

import { eq, and, or, ne } from "drizzle-orm";
import { getDb } from "./db";
import { friendRequests, blockedUsers, users } from "../drizzle/schema";

/**
 * Check if a user is blocked
 */
async function isBlocked(blockerId: number, blockedId: number, db?: any): Promise<boolean> {
  const database = db || (await getDb());
  if (!database) throw new Error("Database not available");

  const block = await database
    .select()
    .from(blockedUsers)
    .where(
      and(
        eq(blockedUsers.blockerId, blockerId),
        eq(blockedUsers.blockedId, blockedId)
      )
    )
    .limit(1);

  return block.length > 0;
}

/**
 * Check if two users are friends
 */
async function areFriends(userId1: number, userId2: number, db?: any): Promise<boolean> {
  const database = db || (await getDb());
  if (!database) throw new Error("Database not available");

  const friendship = await database
    .select()
    .from(friendRequests)
    .where(
      and(
        or(
          and(
            eq(friendRequests.senderId, userId1),
            eq(friendRequests.receiverId, userId2)
          ),
          and(
            eq(friendRequests.senderId, userId2),
            eq(friendRequests.receiverId, userId1)
          )
        ),
        eq(friendRequests.status, "accepted")
      )
    )
    .limit(1);

  return friendship.length > 0;
}

/**
 * Send a friend request
 */
export async function sendFriendRequest(senderId: number, receiverId: number) {
  if (senderId === receiverId) {
    throw new Error("Cannot send friend request to yourself");
  }

  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Check if already friends or request exists
  const existing = await db
    .select()
    .from(friendRequests)
    .where(
      and(
        eq(friendRequests.senderId, senderId),
        eq(friendRequests.receiverId, receiverId)
      )
    )
    .limit(1);

  if (existing.length > 0) {
    throw new Error("Friend request already exists");
  }

  // Check if blocked
  const blocked = await isBlocked(senderId, receiverId, db);
  if (blocked) {
    throw new Error("Cannot send friend request to blocked user");
  }

  await db.insert(friendRequests).values({
    senderId,
    receiverId,
    status: "pending",
  });

  return { success: true };
}

/**
 * Accept a friend request
 */
export async function acceptFriendRequest(requestId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const request = await db
    .select()
    .from(friendRequests)
    .where(eq(friendRequests.id, requestId))
    .limit(1);

  if (request.length === 0) {
    throw new Error("Friend request not found");
  }

  if (request[0].receiverId !== userId) {
    throw new Error("Unauthorized");
  }

  await db
    .update(friendRequests)
    .set({ status: "accepted", respondedAt: new Date() })
    .where(eq(friendRequests.id, requestId));

  return { success: true };
}

/**
 * Reject a friend request
 */
export async function rejectFriendRequest(requestId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const request = await db
    .select()
    .from(friendRequests)
    .where(eq(friendRequests.id, requestId))
    .limit(1);

  if (request.length === 0) {
    throw new Error("Friend request not found");
  }

  if (request[0].receiverId !== userId) {
    throw new Error("Unauthorized");
  }

  await db
    .update(friendRequests)
    .set({ status: "rejected", respondedAt: new Date() })
    .where(eq(friendRequests.id, requestId));

  return { success: true };
}

/**
 * Get pending friend requests for a user
 */
export async function getPendingRequests(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const requests = await db
    .select({
      id: friendRequests.id,
      senderId: friendRequests.senderId,
      senderName: users.name,
      senderEmail: users.email,
      createdAt: friendRequests.createdAt,
    })
    .from(friendRequests)
    .innerJoin(users, eq(friendRequests.senderId, users.id))
    .where(
      and(
        eq(friendRequests.receiverId, userId),
        eq(friendRequests.status, "pending")
      )
    );

  return requests;
}

/**
 * Get friends list for a user
 */
export async function getFriendsList(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const friends = await db
    .select({
      id: users.id,
      name: users.name,
      email: users.email,
      openId: users.openId,
    })
    .from(friendRequests)
    .innerJoin(
      users,
      or(
        and(
          eq(friendRequests.senderId, userId),
          eq(users.id, friendRequests.receiverId)
        ),
        and(
          eq(friendRequests.receiverId, userId),
          eq(users.id, friendRequests.senderId)
        )
      )
    )
    .where(eq(friendRequests.status, "accepted"));

  return friends;
}

/**
 * Get friend suggestions (users not yet connected)
 */
export async function getFriendSuggestions(userId: number, limit: number = 10) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Get all users except self, existing friends, and blocked users
  const suggestions = await db
    .select({
      id: users.id,
      name: users.name,
      email: users.email,
      openId: users.openId,
    })
    .from(users)
    .where(ne(users.id, userId))
    .limit(limit);

  // Filter out existing friends and blocked users
  const filtered = [];
  for (const user of suggestions) {
    const isFriend = await areFriends(userId, user.id, db);
    const isBlockedUser = await isBlocked(userId, user.id, db);

    if (!isFriend && !isBlockedUser) {
      filtered.push(user);
    }
  }

  return filtered.slice(0, limit);
}

/**
 * Get mutual friends between two users
 */
export async function getMutualFriends(userId1: number, userId2: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const friends1 = await getFriendsList(userId1);
  const friends2 = await getFriendsList(userId2);

  const ids1 = new Set(friends1.map((f) => f.id));
  const mutual = friends2.filter((f) => ids1.has(f.id));

  return mutual;
}

/**
 * Block a user
 */
export async function blockUser(blockerId: number, blockedId: number, reason?: string) {
  if (blockerId === blockedId) {
    throw new Error("Cannot block yourself");
  }

  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Check if already blocked
  const existing = await db
    .select()
    .from(blockedUsers)
    .where(
      and(
        eq(blockedUsers.blockerId, blockerId),
        eq(blockedUsers.blockedId, blockedId)
      )
    )
    .limit(1);

  if (existing.length > 0) {
    throw new Error("User already blocked");
  }

  await db.insert(blockedUsers).values({
    blockerId,
    blockedId,
    reason,
  });

  // Remove any friend requests between them
  await db
    .update(friendRequests)
    .set({ status: "rejected" })
    .where(
      or(
        and(
          eq(friendRequests.senderId, blockerId),
          eq(friendRequests.receiverId, blockedId)
        ),
        and(
          eq(friendRequests.senderId, blockedId),
          eq(friendRequests.receiverId, blockerId)
        )
      )
    );

  return { success: true };
}

/**
 * Unblock a user
 */
export async function unblockUser(blockerId: number, blockedId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db
    .delete(blockedUsers)
    .where(
      and(
        eq(blockedUsers.blockerId, blockerId),
        eq(blockedUsers.blockedId, blockedId)
      )
    );

  return { success: true };
}

/**
 * Get blocked users list
 */
export async function getBlockedUsers(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const blocked = await db
    .select({
      id: users.id,
      name: users.name,
      email: users.email,
      reason: blockedUsers.reason,
      blockedAt: blockedUsers.createdAt,
    })
    .from(blockedUsers)
    .innerJoin(users, eq(blockedUsers.blockedId, users.id))
    .where(eq(blockedUsers.blockerId, userId));

  return blocked;
}
