import { COOKIE_NAME } from "@shared/const";
import { z } from "zod";
import { storagePut } from "./storage";
import * as db from "./db";
import { encryptMessage, decryptMessage, sanitizeInput } from "./security";
import {
  isVideoTitleAppropriate,
  isVideoDescriptionAppropriate,
  isContentAppropriate,
  filterProfanity,
} from "./moderation";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { friendsRouter } from "./routers/friends";
import { musicRouter } from "./routers/music";
import { contactsRouter } from "./routers/contacts";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  videos: router({
    upload: protectedProcedure
      .input(z.object({
        title: z.string().min(1).max(255),
        description: z.string().max(5000).optional(),
        videoData: z.string(),
        thumbnailData: z.string().optional(),
        duration: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const title = sanitizeInput(input.title, 255);
        const description = input.description ? sanitizeInput(input.description, 5000) : undefined;
        
        if (!title.trim()) {
          throw new Error("Video title cannot be empty");
        }
        
        if (!isVideoTitleAppropriate(title)) {
          throw new Error("Video title contains inappropriate content");
        }
        
        if (description && !isVideoDescriptionAppropriate(description)) {
          throw new Error("Video description contains inappropriate content");
        }
        
        const videoBuffer = Buffer.from(input.videoData, 'base64');
        const videoKey = `videos/${ctx.user.id}/${Date.now()}.mp4`;
        const { url: videoUrl } = await storagePut(videoKey, videoBuffer, 'video/mp4');
        
        let thumbnailUrl: string | undefined;
        if (input.thumbnailData) {
          const thumbnailBuffer = Buffer.from(input.thumbnailData, 'base64');
          const thumbnailKey = `thumbnails/${ctx.user.id}/${Date.now()}.jpg`;
          const result = await storagePut(thumbnailKey, thumbnailBuffer, 'image/jpeg');
          thumbnailUrl = result.url;
        }
        
        await db.createVideo({
          userId: ctx.user.id,
          title,
          description,
          videoUrl,
          thumbnailUrl,
          duration: input.duration,
        });
        
        return { success: true, videoUrl };
      }),
    
    list: publicProcedure
      .input(z.object({ limit: z.number().optional() }).optional())
      .query(async ({ input }) => {
        return await db.getAllVideos(input?.limit);
      }),
    
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const video = await db.getVideoById(input.id);
        if (video) {
          await db.incrementVideoViews(input.id);
        }
        return video;
      }),
    
    getUserVideos: publicProcedure
      .input(z.object({ userId: z.number() }))
      .query(async ({ input }) => {
        return await db.getVideosByUserId(input.userId);
      }),
  }),
  
  comments: router({
    create: protectedProcedure
      .input(z.object({
        videoId: z.number(),
        content: z.string().min(1).max(5000),
      }))
      .mutation(async ({ ctx, input }) => {
        const sanitized = sanitizeInput(input.content, 5000);
        
        if (!sanitized.trim()) {
          throw new Error("Comment cannot be empty");
        }
        
        if (!isContentAppropriate(sanitized)) {
          throw new Error("Comment contains inappropriate content or violates community guidelines");
        }
        
        const filteredContent = filterProfanity(sanitized);
        
        await db.createComment({
          videoId: input.videoId,
          userId: ctx.user.id,
          content: filteredContent,
        });
        return { success: true };
      }),
    
    list: publicProcedure
      .input(z.object({ videoId: z.number() }))
      .query(async ({ input }) => {
        return await db.getCommentsByVideoId(input.videoId);
      }),
  }),
  
  likes: router({
    toggle: protectedProcedure
      .input(z.object({ videoId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const existing = await db.getUserLike(input.videoId, ctx.user.id);
        if (existing) {
          await db.removeLike(input.videoId, ctx.user.id);
          return { liked: false };
        } else {
          await db.createLike({ videoId: input.videoId, userId: ctx.user.id });
          return { liked: true };
        }
      }),
    
    check: protectedProcedure
      .input(z.object({ videoId: z.number() }))
      .query(async ({ ctx, input }) => {
        const like = await db.getUserLike(input.videoId, ctx.user.id);
        return { liked: !!like };
      }),
  }),
  
  follows: router({
    toggle: protectedProcedure
      .input(z.object({ userId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        if (input.userId === ctx.user.id) {
          throw new Error("Cannot follow yourself");
        }
        
        const isFollowing = await db.isFollowing(ctx.user.id, input.userId);
        if (isFollowing) {
          await db.removeFollow(ctx.user.id, input.userId);
          return { following: false };
        } else {
          await db.createFollow({ followerId: ctx.user.id, followingId: input.userId });
          return { following: true };
        }
      }),
    
    check: protectedProcedure
      .input(z.object({ userId: z.number() }))
      .query(async ({ ctx, input }) => {
        const following = await db.isFollowing(ctx.user.id, input.userId);
        return { following };
      }),
    
    getFollowers: publicProcedure
      .input(z.object({ userId: z.number() }))
      .query(async ({ input }) => {
        return await db.getFollowers(input.userId);
      }),
    
    getFollowing: publicProcedure
      .input(z.object({ userId: z.number() }))
      .query(async ({ input }) => {
        return await db.getFollowing(input.userId);
      }),
  }),
  
  messages: router({
    send: protectedProcedure
      .input(z.object({
        recipientId: z.number(),
        content: z.string().min(1).max(5000),
      }))
      .mutation(async ({ ctx, input }) => {
        if (input.recipientId === ctx.user.id) {
          throw new Error("Cannot message yourself");
        }
        
        const sanitized = sanitizeInput(input.content, 5000);
        const conversation = await db.getOrCreateConversation(ctx.user.id, input.recipientId);
        
        const encryptionKey = `${ctx.user.id}-${input.recipientId}-${process.env.JWT_SECRET || 'default'}`;
        const encryptedContent = encryptMessage(sanitized, encryptionKey);
        
        await db.createMessage({
          conversationId: conversation.id,
          senderId: ctx.user.id,
          content: encryptedContent,
          isEncrypted: 1,
        });
        return { success: true };
      }),
    
    getConversations: protectedProcedure
      .query(async ({ ctx }) => {
        return await db.getUserConversations(ctx.user.id);
      }),
    
    getMessages: protectedProcedure
      .input(z.object({ conversationId: z.number() }))
      .query(async ({ ctx, input }) => {
        const messages = await db.getMessagesByConversationId(input.conversationId);
        
        return messages.map((msg) => {
          if (msg.isEncrypted) {
            try {
              const encryptionKey = `${msg.senderId}-${ctx.user.id}-${process.env.JWT_SECRET || 'default'}`;
              const decryptedContent = decryptMessage(msg.content, encryptionKey);
              return { ...msg, content: decryptedContent };
            } catch (error) {
              console.error("Failed to decrypt message:", error);
              return { ...msg, content: "[Encrypted message - decryption failed]" };
            }
          }
          return msg;
        });
      }),
  }),
  
  search: router({
    all: publicProcedure
      .input(z.object({ query: z.string().min(1).max(100) }))
      .query(async ({ input }) => {
        const sanitized = sanitizeInput(input.query, 100);
        
        if (!sanitized.trim()) {
          return { videos: [], users: [] };
        }
        
        if (!isContentAppropriate(sanitized)) {
          return { videos: [], users: [] };
        }
        
        const videos = await db.searchVideos(sanitized);
        const users = await db.searchUsers(sanitized);
        return { videos, users };
       }),
  }),
  
  friends: friendsRouter,
  music: musicRouter,
  contacts: contactsRouter,
});
export type AppRouter = typeof appRouter;
