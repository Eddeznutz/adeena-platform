import { getDb } from "./db";
import { users } from "../drizzle/schema";
import { eq, inArray, or, like } from "drizzle-orm";

/**
 * Find users by phone numbers or emails from imported contacts
 */
export async function findUsersByContacts(contacts: Array<{ phone?: string; email?: string }>) {
  const db = await getDb();
  if (!db) return [];

  const phones = contacts.map((c) => c.phone).filter(Boolean) as string[];
  const emails = contacts.map((c) => c.email).filter(Boolean) as string[];

  if (phones.length === 0 && emails.length === 0) return [];

  // Build conditions for phone or email matching
  const conditions = [];
  if (emails.length > 0) {
    conditions.push(inArray(users.email, emails));
  }

  if (conditions.length === 0) return [];

  const matchedUsers = await db
    .select({
      id: users.id,
      name: users.name,
      email: users.email,
      openId: users.openId,
    })
    .from(users)
    .where(or(...conditions))
    .limit(100);

  return matchedUsers;
}

/**
 * Search users by name, email, or partial matches
 */
export async function searchUsersByQuery(query: string, limit: number = 20) {
  const db = await getDb();
  if (!db) return [];

  const searchPattern = `%${query}%`;

  const results = await db
    .select({
      id: users.id,
      name: users.name,
      email: users.email,
      openId: users.openId,
    })
    .from(users)
    .where(or(like(users.name, searchPattern), like(users.email, searchPattern)))
    .limit(limit);

  return results;
}
