import { describe, it, expect } from "vitest";
import {
  isPremiumUser,
  calculateRenewalDate,
  getSubscriptionPrice,
  calculateYearlySavings,
  calculateAdRevenue,
  shouldShowAds,
  isValidSubscriptionPlan,
  isValidPaymentStatus,
  generateInvoiceNumber,
  formatPrice,
  isSubscriptionExpiringSoon,
  SubscriptionPlan,
  PaymentStatus,
} from "./monetization";

describe("Monetization System", () => {
  describe("Premium User Status", () => {
    it("should identify active premium users", () => {
      const futureDate = new Date();
      futureDate.setDate(futureDate.getDate() + 30);
      expect(isPremiumUser(1, futureDate)).toBe(true);
    });

    it("should identify expired premium users", () => {
      const pastDate = new Date();
      pastDate.setDate(pastDate.getDate() - 1);
      expect(isPremiumUser(1, pastDate)).toBe(false);
    });

    it("should identify non-premium users", () => {
      expect(isPremiumUser(0, null)).toBe(false);
    });
  });

  describe("Subscription Renewal Dates", () => {
    it("should calculate monthly renewal date", () => {
      const today = new Date();
      const renewal = calculateRenewalDate(SubscriptionPlan.MONTHLY);
      const expectedMonth = today.getMonth() === 11 ? 0 : today.getMonth() + 1;
      expect(renewal.getMonth()).toBe(expectedMonth);
    });

    it("should calculate yearly renewal date", () => {
      const today = new Date();
      const renewal = calculateRenewalDate(SubscriptionPlan.YEARLY);
      const expectedYear = today.getFullYear() + 1;
      expect(renewal.getFullYear()).toBe(expectedYear);
    });
  });

  describe("Subscription Pricing", () => {
    it("should return correct monthly price", () => {
      const price = getSubscriptionPrice(SubscriptionPlan.MONTHLY);
      expect(price).toBe(4.99);
    });

    it("should return correct yearly price", () => {
      const price = getSubscriptionPrice(SubscriptionPlan.YEARLY);
      expect(price).toBe(49.99);
    });

    it("should calculate yearly savings", () => {
      const savings = calculateYearlySavings();
      expect(savings).toBeGreaterThan(0);
      expect(savings).toBeLessThan(12 * 4.99);
    });
  });

  describe("Ad Revenue", () => {
    it("should calculate ad revenue from impressions", () => {
      const revenue = calculateAdRevenue(1000);
      expect(revenue).toBe(0.5);
    });

    it("should calculate revenue for multiple impressions", () => {
      const revenue = calculateAdRevenue(10000);
      expect(revenue).toBe(5);
    });

    it("should handle zero impressions", () => {
      const revenue = calculateAdRevenue(0);
      expect(revenue).toBe(0);
    });
  });

  describe("Ad Display Logic", () => {
    it("should show ads to free users", () => {
      expect(shouldShowAds(false, null)).toBe(true);
    });

    it("should not show ads to active premium users", () => {
      const futureDate = new Date();
      futureDate.setDate(futureDate.getDate() + 30);
      expect(shouldShowAds(true, futureDate)).toBe(false);
    });

    it("should show ads to expired premium users", () => {
      const pastDate = new Date();
      pastDate.setDate(pastDate.getDate() - 1);
      expect(shouldShowAds(true, pastDate)).toBe(true);
    });
  });

  describe("Validation", () => {
    it("should validate subscription plans", () => {
      expect(isValidSubscriptionPlan("monthly")).toBe(true);
      expect(isValidSubscriptionPlan("yearly")).toBe(true);
      expect(isValidSubscriptionPlan("invalid")).toBe(false);
    });

    it("should validate payment statuses", () => {
      expect(isValidPaymentStatus("succeeded")).toBe(true);
      expect(isValidPaymentStatus("failed")).toBe(true);
      expect(isValidPaymentStatus("invalid")).toBe(false);
    });
  });

  describe("Invoice Generation", () => {
    it("should generate unique invoice numbers", () => {
      const inv1 = generateInvoiceNumber(1, 1000);
      const inv2 = generateInvoiceNumber(1, 2000);
      expect(inv1).not.toBe(inv2);
      expect(inv1).toContain("INV-");
    });

    it("should include user ID in invoice", () => {
      const invoice = generateInvoiceNumber(123, 1000);
      expect(invoice).toContain("123");
    });
  });

  describe("Price Formatting", () => {
    it("should format prices correctly", () => {
      const formatted = formatPrice(499);
      expect(formatted).toContain("$");
      expect(formatted).toContain("4.99");
    });

    it("should handle large amounts", () => {
      const formatted = formatPrice(10000);
      expect(formatted).toContain("100");
    });
  });

  describe("Subscription Expiry Warnings", () => {
    it("should warn when subscription expiring soon", () => {
      const soonDate = new Date();
      soonDate.setDate(soonDate.getDate() + 5);
      expect(isSubscriptionExpiringSoon(soonDate, 7)).toBe(true);
    });

    it("should not warn when subscription far from expiry", () => {
      const futureDate = new Date();
      futureDate.setDate(futureDate.getDate() + 30);
      expect(isSubscriptionExpiringSoon(futureDate, 7)).toBe(false);
    });

    it("should not warn for expired subscriptions", () => {
      const pastDate = new Date();
      pastDate.setDate(pastDate.getDate() - 1);
      expect(isSubscriptionExpiringSoon(pastDate, 7)).toBe(false);
    });

    it("should handle null expiry date", () => {
      expect(isSubscriptionExpiringSoon(null, 7)).toBe(false);
    });
  });
});
