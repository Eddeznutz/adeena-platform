/**
 * Monetization System
 * Handles premium subscriptions, payments, and ad revenue
 */

export enum SubscriptionPlan {
  MONTHLY = "monthly",
  YEARLY = "yearly",
}

export enum SubscriptionStatus {
  ACTIVE = "active",
  CANCELED = "canceled",
  EXPIRED = "expired",
}

export enum PaymentStatus {
  PENDING = "pending",
  SUCCEEDED = "succeeded",
  FAILED = "failed",
  REFUNDED = "refunded",
}

/**
 * Subscription pricing configuration
 */
export const SUBSCRIPTION_PRICING = {
  monthly: {
    price: 499, // $4.99 in cents
    currency: "USD",
    interval: "month",
    name: "Premium Monthly",
  },
  yearly: {
    price: 4999, // $49.99 in cents (saves $9.89/year)
    currency: "USD",
    interval: "year",
    name: "Premium Yearly",
  },
};

/**
 * Premium features
 */
export const PREMIUM_FEATURES = {
  adFree: true,
  customBadge: true,
  analyticsAccess: true,
  prioritySupport: true,
  exclusiveContent: true,
  advancedFilters: true,
};

/**
 * Check if user has active premium subscription
 */
export function isPremiumUser(isPremium: number, premiumExpiresAt: Date | null): boolean {
  if (!isPremium || !premiumExpiresAt) {
    return false;
  }

  const now = new Date();
  return premiumExpiresAt > now;
}

/**
 * Calculate subscription renewal date
 */
export function calculateRenewalDate(plan: SubscriptionPlan): Date {
  const date = new Date();

  if (plan === SubscriptionPlan.MONTHLY) {
    date.setMonth(date.getMonth() + 1);
  } else if (plan === SubscriptionPlan.YEARLY) {
    date.setFullYear(date.getFullYear() + 1);
  }

  return date;
}

/**
 * Get subscription price in dollars
 */
export function getSubscriptionPrice(plan: SubscriptionPlan): number {
  return SUBSCRIPTION_PRICING[plan].price / 100;
}

/**
 * Calculate savings for yearly plan
 */
export function calculateYearlySavings(): number {
  const monthlyTotal = SUBSCRIPTION_PRICING.monthly.price * 12;
  const yearlyPrice = SUBSCRIPTION_PRICING.yearly.price;
  return (monthlyTotal - yearlyPrice) / 100;
}

/**
 * Ad revenue configuration
 */
export const AD_CONFIG = {
  impressionValue: 0.5, // $0.50 per 1000 impressions (CPM)
  clickValue: 2.0, // $2.00 per click (CPC)
  videoAdFrequency: 5, // Show ad every 5 videos
  showAdsToFreeUsers: true,
  showAdsToNonPremium: true,
  showAdsToAdFreeUsers: false,
};

/**
 * Calculate ad revenue from impressions
 */
export function calculateAdRevenue(impressions: number): number {
  return (impressions / 1000) * AD_CONFIG.impressionValue;
}

/**
 * Determine if user should see ads
 */
export function shouldShowAds(isPremium: boolean, premiumExpiresAt: Date | null): boolean {
  // Check if user has active premium subscription
  if (isPremium && premiumExpiresAt && premiumExpiresAt > new Date()) {
    // Premium users don't see ads
    return false;
  }

  // Free users see ads if configured
  return AD_CONFIG.showAdsToFreeUsers;
}

/**
 * Validate subscription plan
 */
export function isValidSubscriptionPlan(plan: string): boolean {
  return Object.values(SubscriptionPlan).includes(plan as SubscriptionPlan);
}

/**
 * Validate payment status
 */
export function isValidPaymentStatus(status: string): boolean {
  return Object.values(PaymentStatus).includes(status as PaymentStatus);
}

/**
 * Generate invoice number
 */
export function generateInvoiceNumber(userId: number, timestamp: number): string {
  return `INV-${userId}-${timestamp}`;
}

/**
 * Format price for display
 */
export function formatPrice(cents: number, currency: string = "USD"): string {
  const dollars = cents / 100;
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency,
  }).format(dollars);
}

/**
 * Calculate trial period end date
 */
export function calculateTrialEndDate(days: number = 7): Date {
  const date = new Date();
  date.setDate(date.getDate() + days);
  return date;
}

/**
 * Check if subscription is about to expire
 */
export function isSubscriptionExpiringSoon(
  premiumExpiresAt: Date | null,
  daysThreshold: number = 7
): boolean {
  if (!premiumExpiresAt) {
    return false;
  }

  const now = new Date();
  const daysUntilExpiry = Math.ceil(
    (premiumExpiresAt.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)
  );

  return daysUntilExpiry <= daysThreshold && daysUntilExpiry > 0;
}
