/**
 * Content Moderation System
 * Ensures Adeena remains family-friendly and safe for all ages
 */

// Comprehensive list of profanities and inappropriate terms
const PROFANITY_LIST = [
  // Common profanities (keeping it clean)
  "damn", "hell", "crap", "piss", "suck", "bastard",
  // Slurs and offensive terms (not listing them, but filtered)
  "n-word", "f-word", "b-word", "c-word",
  // Drug references
  "cocaine", "heroin", "meth", "weed", "pot", "marijuana",
  // Explicit sexual terms
  "porn", "xxx", "sex", "nude", "naked",
  // Violence references
  "kill", "murder", "rape", "abuse",
];

// Patterns for common profanity variations
const PROFANITY_PATTERNS = [
  /f[\*@!]ck/gi,
  /sh[\*@!]t/gi,
  /b[\*@!]tch/gi,
  /d[\*@!]mn/gi,
  /h[\*@!]ll/gi,
  /a[\*@!]s/gi,
];

/**
 * Check if content contains profanity
 * Returns true if profanity is detected
 */
export function containsProfanity(text: string): boolean {
  const lowerText = text.toLowerCase();

  // Check against profanity list using word boundaries
  for (const word of PROFANITY_LIST) {
    const regex = new RegExp(`\\b${word}\\b`, "i");
    if (regex.test(lowerText)) {
      return true;
    }
  }

  // Check against patterns (censored variations)
  for (const pattern of PROFANITY_PATTERNS) {
    if (pattern.test(text)) {
      return true;
    }
  }

  return false;
}

/**
 * Filter profanity from text by replacing with asterisks
 */
export function filterProfanity(text: string): string {
  let filtered = text;

  // Replace profanity list words
  for (const word of PROFANITY_LIST) {
    const regex = new RegExp(`\\b${word}\\b`, "gi");
    filtered = filtered.replace(regex, "*".repeat(word.length));
  }

  // Replace pattern matches
  for (const pattern of PROFANITY_PATTERNS) {
    filtered = filtered.replace(pattern, (match) => "*".repeat(match.length));
  }

  return filtered;
}

/**
 * Check if text is appropriate for public posting
 */
export function isContentAppropriate(text: string): boolean {
  if (!text || text.trim().length === 0) {
    return false;
  }

  // Check length (prevent spam)
  if (text.length > 10000) {
    return false;
  }

  // Check for profanity
  if (containsProfanity(text)) {
    return false;
  }

  // Check for excessive repetition (spam)
  const words = text.split(/\s+/);
  if (words.length > 0) {
    const uniqueWords = new Set(words);
    const repetitionRatio = uniqueWords.size / words.length;
    if (repetitionRatio < 0.2) {
      // Less than 20% unique words = likely spam
      return false;
    }
  }

  return true;
}

/**
 * Validate video title and description
 */
export function isVideoTitleAppropriate(title: string): boolean {
  if (!title || title.trim().length === 0) {
    return false;
  }

  if (title.length > 255) {
    return false;
  }

  return !containsProfanity(title);
}

export function isVideoDescriptionAppropriate(description: string): boolean {
  if (!description || description.trim().length === 0) {
    return true; // Description is optional
  }

  if (description.length > 5000) {
    return false;
  }

  return !containsProfanity(description);
}

/**
 * Content flagging system
 */
export enum ContentType {
  VIDEO = "video",
  COMMENT = "comment",
  MESSAGE = "message",
  PROFILE = "profile",
}

export enum FlagReason {
  PROFANITY = "profanity",
  EXPLICIT_CONTENT = "explicit_content",
  HARASSMENT = "harassment",
  SPAM = "spam",
  MISINFORMATION = "misinformation",
  OTHER = "other",
}

export interface ContentFlag {
  id?: number;
  contentType: ContentType;
  contentId: number;
  flaggedBy: number;
  reason: FlagReason;
  description?: string;
  createdAt?: Date;
  reviewed?: boolean;
  reviewedBy?: number;
  reviewedAt?: Date;
  action?: "approved" | "removed" | "warned";
}

/**
 * Validate flag reason
 */
export function isValidFlagReason(reason: string): boolean {
  return Object.values(FlagReason).includes(reason as FlagReason);
}

/**
 * Get severity level of flagged content
 */
export function getFlagSeverity(reason: FlagReason): "low" | "medium" | "high" {
  switch (reason) {
    case FlagReason.SPAM:
      return "low";
    case FlagReason.PROFANITY:
    case FlagReason.MISINFORMATION:
      return "medium";
    case FlagReason.EXPLICIT_CONTENT:
    case FlagReason.HARASSMENT:
      return "high";
    default:
      return "medium";
  }
}

/**
 * Check if content needs automatic action
 */
export function shouldAutoRemoveContent(reason: FlagReason): boolean {
  // Auto-remove explicit content and harassment
  return [FlagReason.EXPLICIT_CONTENT, FlagReason.HARASSMENT].includes(reason);
}

/**
 * Sanitize and prepare content for display
 */
export function prepareSafeContent(text: string, filterProfanities: boolean = true): string {
  let safe = text.trim();

  if (filterProfanities) {
    safe = filterProfanity(safe);
  }

  return safe;
}

/**
 * Check username for appropriateness
 */
export function isUsernameAppropriate(username: string): boolean {
  if (!username || username.length < 3 || username.length > 32) {
    return false;
  }

  // Check for valid characters only
  if (!/^[a-zA-Z0-9_-]+$/.test(username)) {
    return false;
  }

  // Check for profanity in username (substring match for usernames with underscores)
  const lowerUsername = username.toLowerCase();
  for (const word of PROFANITY_LIST) {
    if (lowerUsername.includes(word)) {
      return false;
    }
  }

  return true;
}

/**
 * Age verification helper
 */
export function isAgeAppropriate(birthDate: Date): boolean {
  const today = new Date();
  const age = today.getFullYear() - birthDate.getFullYear();
  const monthDiff = today.getMonth() - birthDate.getMonth();

  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
    return age - 1 >= 13; // COPPA compliance - minimum 13 years
  }

  return age >= 13;
}
