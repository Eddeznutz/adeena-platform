import { describe, it, expect } from "vitest";
import {
  encryptMessage,
  decryptMessage,
  sanitizeInput,
  validateEmail,
  validateUsername,
  generateSecureToken,
  hashValue,
  constantTimeCompare,
} from "./security";

describe("Security Utilities", () => {
  describe("Message Encryption/Decryption", () => {
    it("should encrypt and decrypt messages correctly", () => {
      const message = "Hello, this is a secret message!";
      const key = "test-encryption-key";

      const encrypted = encryptMessage(message, key);
      const decrypted = decryptMessage(encrypted, key);

      expect(decrypted).toBe(message);
      expect(encrypted).not.toBe(message);
    });

    it("should produce different ciphertexts for the same message", () => {
      const message = "Same message";
      const key = "test-key";

      const encrypted1 = encryptMessage(message, key);
      const encrypted2 = encryptMessage(message, key);

      expect(encrypted1).not.toBe(encrypted2);
    });

    it("should fail to decrypt with wrong key", () => {
      const message = "Secret";
      const key1 = "correct-key";
      const key2 = "wrong-key";

      const encrypted = encryptMessage(message, key1);

      expect(() => {
        decryptMessage(encrypted, key2);
      }).toThrow();
    });

    it("should handle long messages", () => {
      const longMessage = "A".repeat(5000);
      const key = "test-key";

      const encrypted = encryptMessage(longMessage, key);
      const decrypted = decryptMessage(encrypted, key);

      expect(decrypted).toBe(longMessage);
    });

    it("should handle special characters", () => {
      const message = "Special chars: !@#$%^&*()_+-=[]{}|;:',.<>?/~`";
      const key = "test-key";

      const encrypted = encryptMessage(message, key);
      const decrypted = decryptMessage(encrypted, key);

      expect(decrypted).toBe(message);
    });
  });

  describe("Input Sanitization", () => {
    it("should remove HTML tags", () => {
      const input = "<script>alert('xss')</script>";
      const sanitized = sanitizeInput(input);

      expect(sanitized).not.toContain("<script>");
      expect(sanitized).not.toContain("</script>");
    });

    it("should escape dangerous characters", () => {
      const input = 'Test with "quotes" and <tags>';
      const sanitized = sanitizeInput(input);

      expect(sanitized).toContain("&quot;");
      expect(sanitized).toContain("&lt;");
    });

    it("should respect max length", () => {
      const input = "A".repeat(1000);
      const sanitized = sanitizeInput(input, 100);

      expect(sanitized.length).toBeLessThanOrEqual(100);
    });

    it("should trim whitespace", () => {
      const input = "  hello world  ";
      const sanitized = sanitizeInput(input);

      expect(sanitized).toBe("hello world");
    });

    it("should handle empty strings", () => {
      const sanitized = sanitizeInput("");
      expect(sanitized).toBe("");
    });
  });

  describe("Email Validation", () => {
    it("should validate correct emails", () => {
      expect(validateEmail("user@example.com")).toBe(true);
      expect(validateEmail("test.user+tag@domain.co.uk")).toBe(true);
    });

    it("should reject invalid emails", () => {
      expect(validateEmail("invalid")).toBe(false);
      expect(validateEmail("@example.com")).toBe(false);
      expect(validateEmail("user@")).toBe(false);
      expect(validateEmail("user @example.com")).toBe(false);
    });

    it("should reject emails that are too long", () => {
      const longEmail = "a".repeat(320) + "@example.com";
      expect(validateEmail(longEmail)).toBe(false);
    });
  });

  describe("Username Validation", () => {
    it("should validate correct usernames", () => {
      expect(validateUsername("user123")).toBe(true);
      expect(validateUsername("test_user")).toBe(true);
      expect(validateUsername("user-name")).toBe(true);
    });

    it("should reject invalid usernames", () => {
      expect(validateUsername("ab")).toBe(false); // Too short
      expect(validateUsername("user@name")).toBe(false); // Invalid char
      expect(validateUsername("user name")).toBe(false); // Space
      expect(validateUsername("a".repeat(33))).toBe(false); // Too long
    });
  });

  describe("Token Generation", () => {
    it("should generate random tokens", () => {
      const token1 = generateSecureToken();
      const token2 = generateSecureToken();

      expect(token1).not.toBe(token2);
      expect(token1.length).toBe(64); // 32 bytes * 2 (hex)
    });

    it("should generate tokens of specified length", () => {
      const token = generateSecureToken(16);
      expect(token.length).toBe(32); // 16 bytes * 2 (hex)
    });
  });

  describe("Value Hashing", () => {
    it("should hash values consistently", () => {
      const value = "test-value";
      const hash1 = hashValue(value);
      const hash2 = hashValue(value);

      expect(hash1).toBe(hash2);
    });

    it("should produce different hashes for different values", () => {
      const hash1 = hashValue("value1");
      const hash2 = hashValue("value2");

      expect(hash1).not.toBe(hash2);
    });

    it("should produce fixed-length hashes", () => {
      const hash = hashValue("any value");
      expect(hash.length).toBe(64); // SHA-256 hex
    });
  });

  describe("Constant Time Comparison", () => {
    it("should return true for equal strings", () => {
      expect(constantTimeCompare("test", "test")).toBe(true);
    });

    it("should return false for different strings", () => {
      expect(constantTimeCompare("test1", "test2")).toBe(false);
    });

    it("should return false for different lengths", () => {
      expect(constantTimeCompare("short", "much longer string")).toBe(false);
    });

    it("should prevent timing attacks", () => {
      // This test verifies that the function uses timing-safe comparison
      // The actual timing difference is negligible in tests, but the implementation
      // uses crypto.timingSafeEqual which is resistant to timing attacks
      const result1 = constantTimeCompare("a".repeat(1000), "a".repeat(1000));
      const result2 = constantTimeCompare("a".repeat(1000), "b".repeat(1000));

      expect(result1).toBe(true);
      expect(result2).toBe(false);
    });
  });
});
