import { describe, it, expect } from "vitest";
import {
  containsProfanity,
  filterProfanity,
  isContentAppropriate,
  isVideoTitleAppropriate,
  isVideoDescriptionAppropriate,
  isUsernameAppropriate,
  isAgeAppropriate,
  isValidFlagReason,
  getFlagSeverity,
  shouldAutoRemoveContent,
  FlagReason,
} from "./moderation";

describe("Content Moderation", () => {
  describe("Profanity Detection", () => {
    it("should detect profanity in text", () => {
      expect(containsProfanity("This is damn bad")).toBe(true);
      expect(containsProfanity("What the hell")).toBe(true);
      expect(containsProfanity("This is crap")).toBe(true);
    });

    it("should detect censored profanity variations", () => {
      expect(containsProfanity("What the f*ck")).toBe(true);
      expect(containsProfanity("Sh!t happens")).toBe(true);
      expect(containsProfanity("B@tch please")).toBe(true);
    });

    it("should not flag clean text", () => {
      expect(containsProfanity("This is a clean message")).toBe(false);
      expect(containsProfanity("Hello world")).toBe(false);
      expect(containsProfanity("Great video!")).toBe(false);
    });

    it("should be case insensitive", () => {
      expect(containsProfanity("DAMN")).toBe(true);
      expect(containsProfanity("DaMn")).toBe(true);
      expect(containsProfanity("damn")).toBe(true);
    });
  });

  describe("Profanity Filtering", () => {
    it("should filter profanity with asterisks", () => {
      const filtered = filterProfanity("This is damn bad");
      expect(filtered).toContain("****");
      expect(filtered).not.toContain("damn");
    });

    it("should preserve word length", () => {
      const filtered = filterProfanity("What the hell");
      expect(filtered).toContain("****"); // 4 asterisks for "hell"
    });

    it("should filter multiple profanities", () => {
      const filtered = filterProfanity("This damn hell crap");
      expect(filtered).not.toContain("damn");
      expect(filtered).not.toContain("hell");
      expect(filtered).not.toContain("crap");
    });
  });

  describe("Content Appropriateness", () => {
    it("should approve clean content", () => {
      expect(isContentAppropriate("This is a great video!")).toBe(true);
      expect(isContentAppropriate("Love this content")).toBe(true);
    });

    it("should reject profane content", () => {
      expect(isContentAppropriate("This is damn bad")).toBe(false);
      expect(isContentAppropriate("What the hell")).toBe(false);
    });

    it("should reject empty content", () => {
      expect(isContentAppropriate("")).toBe(false);
      expect(isContentAppropriate("   ")).toBe(false);
    });

    it("should reject excessively long content", () => {
      const longText = "a".repeat(10001);
      expect(isContentAppropriate(longText)).toBe(false);
    });

    it("should reject spam (excessive repetition)", () => {
      const spam = "spam spam spam spam spam spam spam spam spam spam";
      expect(isContentAppropriate(spam)).toBe(false);
    });

    it("should accept varied content", () => {
      const varied = "This is a great video with lots of different words and ideas";
      expect(isContentAppropriate(varied)).toBe(true);
    });
  });

  describe("Video Title Validation", () => {
    it("should approve appropriate titles", () => {
      expect(isVideoTitleAppropriate("Amazing Video")).toBe(true);
      expect(isVideoTitleAppropriate("My First Upload")).toBe(true);
    });

    it("should reject profane titles", () => {
      expect(isVideoTitleAppropriate("Damn Video")).toBe(false);
      expect(isVideoTitleAppropriate("What the Hell")).toBe(false);
    });

    it("should reject empty titles", () => {
      expect(isVideoTitleAppropriate("")).toBe(false);
      expect(isVideoTitleAppropriate("   ")).toBe(false);
    });

    it("should reject overly long titles", () => {
      const longTitle = "a".repeat(256);
      expect(isVideoTitleAppropriate(longTitle)).toBe(false);
    });
  });

  describe("Video Description Validation", () => {
    it("should approve appropriate descriptions", () => {
      expect(isVideoDescriptionAppropriate("Great content")).toBe(true);
      expect(isVideoDescriptionAppropriate("Check out this amazing video")).toBe(true);
    });

    it("should allow empty descriptions", () => {
      expect(isVideoDescriptionAppropriate("")).toBe(true);
      expect(isVideoDescriptionAppropriate("   ")).toBe(true);
    });

    it("should reject profane descriptions", () => {
      expect(isVideoDescriptionAppropriate("This is damn good")).toBe(false);
    });

    it("should reject overly long descriptions", () => {
      const longDesc = "a".repeat(5001);
      expect(isVideoDescriptionAppropriate(longDesc)).toBe(false);
    });
  });

  describe("Username Validation", () => {
    it("should approve appropriate usernames", () => {
      expect(isUsernameAppropriate("john_doe")).toBe(true);
      expect(isUsernameAppropriate("user123")).toBe(true);
      expect(isUsernameAppropriate("jane-smith")).toBe(true);
    });

    it("should reject profane usernames", () => {
      expect(isUsernameAppropriate("damn_user")).toBe(false);
      expect(isUsernameAppropriate("hell_yeah")).toBe(false);
    });

    it("should reject invalid usernames", () => {
      expect(isUsernameAppropriate("ab")).toBe(false); // Too short
      expect(isUsernameAppropriate("a".repeat(33))).toBe(false); // Too long
      expect(isUsernameAppropriate("user@name")).toBe(false); // Invalid char
      expect(isUsernameAppropriate("user name")).toBe(false); // Space
    });
  });

  describe("Age Verification", () => {
    it("should approve users 13 and older", () => {
      const thirteenYearsAgo = new Date();
      thirteenYearsAgo.setFullYear(thirteenYearsAgo.getFullYear() - 13);
      expect(isAgeAppropriate(thirteenYearsAgo)).toBe(true);
    });

    it("should reject users under 13", () => {
      const twelveYearsAgo = new Date();
      twelveYearsAgo.setFullYear(twelveYearsAgo.getFullYear() - 12);
      expect(isAgeAppropriate(twelveYearsAgo)).toBe(false);
    });

    it("should approve adults", () => {
      const thirtyYearsAgo = new Date();
      thirtyYearsAgo.setFullYear(thirtyYearsAgo.getFullYear() - 30);
      expect(isAgeAppropriate(thirtyYearsAgo)).toBe(true);
    });
  });

  describe("Flag Reason Validation", () => {
    it("should validate correct flag reasons", () => {
      expect(isValidFlagReason("profanity")).toBe(true);
      expect(isValidFlagReason("explicit_content")).toBe(true);
      expect(isValidFlagReason("harassment")).toBe(true);
      expect(isValidFlagReason("spam")).toBe(true);
    });

    it("should reject invalid flag reasons", () => {
      expect(isValidFlagReason("invalid_reason")).toBe(false);
      expect(isValidFlagReason("")).toBe(false);
    });
  });

  describe("Flag Severity", () => {
    it("should assign correct severity levels", () => {
      expect(getFlagSeverity(FlagReason.SPAM)).toBe("low");
      expect(getFlagSeverity(FlagReason.PROFANITY)).toBe("medium");
      expect(getFlagSeverity(FlagReason.EXPLICIT_CONTENT)).toBe("high");
      expect(getFlagSeverity(FlagReason.HARASSMENT)).toBe("high");
    });
  });

  describe("Auto-Remove Decision", () => {
    it("should auto-remove explicit content", () => {
      expect(shouldAutoRemoveContent(FlagReason.EXPLICIT_CONTENT)).toBe(true);
    });

    it("should auto-remove harassment", () => {
      expect(shouldAutoRemoveContent(FlagReason.HARASSMENT)).toBe(true);
    });

    it("should not auto-remove other content", () => {
      expect(shouldAutoRemoveContent(FlagReason.SPAM)).toBe(false);
      expect(shouldAutoRemoveContent(FlagReason.PROFANITY)).toBe(false);
    });
  });
});
