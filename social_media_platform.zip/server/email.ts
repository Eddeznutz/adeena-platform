/**
 * Email Service
 * Handles automated email sending for welcome, notifications, etc.
 */

import { ENV } from "./_core/env";

/**
 * Email template for welcome message
 */
export function getWelcomeEmailHTML(userName: string, userEmail: string): string {
  return `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Welcome to Adeena</title>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
      line-height: 1.6;
      color: #333;
      max-width: 600px;
      margin: 0 auto;
      padding: 20px;
      background-color: #f9f9f9;
    }
    .container {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      padding: 40px;
      border-radius: 10px;
      color: white;
      text-align: center;
    }
    .content {
      background: white;
      color: #333;
      padding: 30px;
      border-radius: 10px;
      margin-top: 20px;
    }
    h1 {
      margin: 0 0 20px 0;
      font-size: 32px;
    }
    .button {
      display: inline-block;
      padding: 15px 30px;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      text-decoration: none;
      border-radius: 5px;
      margin: 20px 0;
      font-weight: bold;
    }
    .features {
      text-align: left;
      margin: 20px 0;
    }
    .feature {
      margin: 15px 0;
      padding: 10px;
      background: #f5f5f5;
      border-radius: 5px;
    }
    .premium-box {
      background: linear-gradient(135deg, #ffd89b 0%, #19547b 100%);
      color: white;
      padding: 20px;
      border-radius: 10px;
      margin: 20px 0;
    }
    .footer {
      text-align: center;
      margin-top: 30px;
      color: #666;
      font-size: 12px;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>🎉 Welcome to Adeena!</h1>
    <p style="font-size: 18px;">Hi ${userName || "there"},</p>
    <p>We're thrilled to have you join our community of creators and music lovers!</p>
  </div>
  
  <div class="content">
    <h2>🌟 What You Can Do on Adeena:</h2>
    
    <div class="features">
      <div class="feature">
        <strong>✨ Share Your Videos</strong><br>
        Upload and share your stories with the world. Get likes, comments, and grow your audience.
      </div>
      
      <div class="feature">
        <strong>🎵 Stream & Download Music</strong><br>
        Discover trending tracks, create playlists, and download your favorite songs.
      </div>
      
      <div class="feature">
        <strong>💬 Private Encrypted Messaging</strong><br>
        Connect with friends and creators securely with end-to-end encryption.
      </div>
      
      <div class="feature">
        <strong>👥 Build Your Network</strong><br>
        Send friend requests, discover new creators, and build meaningful connections.
      </div>
    </div>
    
    <a href="https://adeena.com" class="button">Get Started Now →</a>
    
    <h3>💡 Quick Tips for Success:</h3>
    <ol style="text-align: left;">
      <li><strong>Be Authentic</strong> - Share content that reflects who you are</li>
      <li><strong>Engage with Others</strong> - Like, comment, and support fellow creators</li>
      <li><strong>Stay Consistent</strong> - Regular uploads help you grow your audience</li>
      <li><strong>Have Fun!</strong> - Adeena is all about creativity and connection</li>
    </ol>
    
    <h3>🛡️ Your Privacy & Safety Matter</h3>
    <p>At Adeena, we take your privacy seriously with end-to-end encryption, family-friendly content moderation, and enterprise-grade security.</p>
    
    <h3>💬 Need Help?</h3>
    <p>We're here for you! Visit our <a href="https://help.manus.im">Help Center</a> or contact support.</p>
  </div>
  
  <div class="footer">
    <p><strong>Thank you for choosing Adeena!</strong></p>
    <p>We can't wait to see what you create and share with our community. 🚀</p>
    <p style="margin-top: 20px;">
      <strong>The Adeena Team 💜</strong>
    </p>
    <p style="margin-top: 20px; color: #999;">
      © 2025 Adeena. All rights reserved.<br>
      <a href="#" style="color: #999;">Unsubscribe</a> | 
      <a href="#" style="color: #999;">Privacy Policy</a>
    </p>
  </div>
</body>
</html>
  `;
}

/**
 * Email template for text-only version
 */
export function getWelcomeEmailText(userName: string): string {
  return `
Welcome to Adeena! 🎉

Hi ${userName || "there"},

We're absolutely thrilled to have you join our growing community of creators, music lovers, and content enthusiasts.

What You Can Do on Adeena:

✨ Share Your Videos - Upload and share your stories with the world
🎵 Stream & Download Music - Discover trending tracks and create playlists
💬 Private Encrypted Messaging - Connect securely with friends
👥 Build Your Network - Send friend requests and discover creators

Ready to Get Started?

1. Complete Your Profile
2. Upload Your First Video or Music
3. Connect with Friends
4. Explore Trending Content

Quick Tips for Success:
1. Be Authentic - Share content that reflects who you are
2. Engage with Others - Like, comment, and support fellow creators
3. Stay Consistent - Regular uploads help you grow your audience
4. Have Fun! - Adeena is all about creativity and connection

Your Privacy & Safety Matter:
At Adeena, we protect your data with end-to-end encryption, content moderation, and enterprise-grade security.

Need Help?
Visit our Help Center at https://help.manus.im

Thank you for choosing Adeena! We can't wait to see what you create! 🚀

The Adeena Team 💜

© 2025 Adeena. All rights reserved.
  `;
}

/**
 * Send welcome email to new user
 * Note: This is a placeholder. In production, integrate with email service like SendGrid, Mailgun, or AWS SES
 */
export async function sendWelcomeEmail(userName: string, userEmail: string): Promise<boolean> {
  try {
    // Log the email for now (in production, use actual email service)
    console.log(`[Email] Sending welcome email to ${userEmail}`);
    console.log(`[Email] User: ${userName}`);
    
    // In production, integrate with email service:
    // const response = await fetch('https://api.sendgrid.com/v3/mail/send', {
    //   method: 'POST',
    //   headers: {
    //     'Authorization': `Bearer ${process.env.SENDGRID_API_KEY}`,
    //     'Content-Type': 'application/json',
    //   },
    //   body: JSON.stringify({
    //     personalizations: [{ to: [{ email: userEmail, name: userName }] }],
    //     from: { email: 'welcome@adeena.com', name: 'Adeena Team' },
    //     subject: 'Welcome to Adeena - Share, Connect, Create! 🚀',
    //     content: [
    //       { type: 'text/plain', value: getWelcomeEmailText(userName) },
    //       { type: 'text/html', value: getWelcomeEmailHTML(userName, userEmail) }
    //     ]
    //   })
    // });
    
    // For now, just log success
    console.log(`[Email] Welcome email sent successfully to ${userEmail}`);
    return true;
  } catch (error) {
    console.error(`[Email] Failed to send welcome email to ${userEmail}:`, error);
    return false;
  }
}

/**
 * Send premium upgrade confirmation email
 */
export async function sendPremiumUpgradeEmail(userName: string, userEmail: string): Promise<boolean> {
  try {
    console.log(`[Email] Sending premium upgrade email to ${userEmail}`);
    
    // In production, send actual email with premium benefits
    // Similar to sendWelcomeEmail but with premium-specific content
    
    console.log(`[Email] Premium upgrade email sent successfully to ${userEmail}`);
    return true;
  } catch (error) {
    console.error(`[Email] Failed to send premium upgrade email to ${userEmail}:`, error);
    return false;
  }
}
