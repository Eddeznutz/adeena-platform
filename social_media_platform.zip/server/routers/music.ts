/**
 * Music Router - tRPC procedures for music streaming
 */

import { z } from "zod";
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";
import { storagePut } from "../storage";
import {
  uploadMusic,
  getUserMusic,
  getPublicMusic,
  getMusicById,
  searchMusic,
  incrementMusicPlays,
  likeMusicTrack,
  unlikeMusicTrack,
  getUserLikedMusic,
  createPlaylist,
  getUserPlaylists,
  getPlaylistWithSongs,
  addSongToPlaylist,
  removeSongFromPlaylist,
  deletePlaylist,
  incrementPlaylistPlays,
  getTrendingMusic,
  getMusicByGenre,
  getMusicByArtist,
  incrementMusicDownloads,
} from "../music";

export const musicRouter = router({
  /**
   * Upload a music track
   */
  upload: protectedProcedure
    .input(
      z.object({
        title: z.string().min(1).max(255),
        artist: z.string().optional(),
        album: z.string().optional(),
        genre: z.string().optional(),
        description: z.string().optional(),
        coverUrl: z.string().optional(),
        duration: z.number().optional(),
        musicFile: z.string(), // Base64 encoded or URL
      })
    )
    .mutation(async ({ input, ctx }) => {
      // Upload music file to S3
      const fileKey = `music/${ctx.user.id}/${input.title}-${Date.now()}.mp3`;
      const { url } = await storagePut(fileKey, input.musicFile, "audio/mpeg");

      return uploadMusic(
        ctx.user.id,
        input.title,
        url,
        input.artist,
        input.album,
        input.genre,
        input.description,
        input.coverUrl,
        input.duration
      );
    }),

  /**
   * Get user's music tracks
   */
  getUserMusic: protectedProcedure.query(async ({ ctx }) => {
    return getUserMusic(ctx.user.id);
  }),

  /**
   * Get public music tracks
   */
  getPublic: publicProcedure
    .input(z.object({ limit: z.number().default(50), offset: z.number().default(0) }))
    .query(async ({ input }) => {
      return getPublicMusic(input.limit, input.offset);
    }),

  /**
   * Get music by ID
   */
  getById: publicProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      return getMusicById(input.id);
    }),

  /**
   * Search music
   */
  search: publicProcedure
    .input(z.object({ query: z.string().min(1).max(100) }))
    .query(async ({ input }) => {
      return searchMusic(input.query);
    }),

  /**
   * Play music (increment play count)
   */
  play: publicProcedure
    .input(z.object({ musicId: z.number() }))
    .mutation(async ({ input }) => {
      return incrementMusicPlays(input.musicId);
    }),

  /**
   * Like a music track
   */
  like: protectedProcedure
    .input(z.object({ musicId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      return likeMusicTrack(ctx.user.id, input.musicId);
    }),

  /**
   * Unlike a music track
   */
  unlike: protectedProcedure
    .input(z.object({ musicId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      return unlikeMusicTrack(ctx.user.id, input.musicId);
    }),

  /**
   * Get user's liked music
   */
  getLiked: protectedProcedure.query(async ({ ctx }) => {
    return getUserLikedMusic(ctx.user.id);
  }),

  /**
   * Get trending music
   */
  getTrending: publicProcedure
    .input(z.object({ limit: z.number().default(20) }))
    .query(async ({ input }) => {
      return getTrendingMusic(input.limit);
    }),

  /**
   * Get music by genre
   */
  getByGenre: publicProcedure
    .input(z.object({ genre: z.string(), limit: z.number().default(20) }))
    .query(async ({ input }) => {
      return getMusicByGenre(input.genre, input.limit);
    }),

  /**
   * Get music by artist
   */
  getByArtist: publicProcedure
    .input(z.object({ artist: z.string(), limit: z.number().default(20) }))
    .query(async ({ input }) => {
      return getMusicByArtist(input.artist, input.limit);
    }),

  /**
   * Download music (increment download count)
   */
  download: publicProcedure
    .input(z.object({ musicId: z.number() }))
    .mutation(async ({ input }) => {
      return incrementMusicDownloads(input.musicId);
    }),

  /**
   * Playlists
   */
  playlists: router({
    /**
     * Create a new playlist
     */
    create: protectedProcedure
      .input(
        z.object({
          name: z.string().min(1).max(255),
          description: z.string().optional(),
          coverUrl: z.string().optional(),
          isPublic: z.number().default(1),
        })
      )
      .mutation(async ({ input, ctx }) => {
        return createPlaylist(ctx.user.id, input.name, input.description, input.coverUrl, input.isPublic);
      }),

    /**
     * Get user's playlists
     */
    getUserPlaylists: protectedProcedure.query(async ({ ctx }) => {
      return getUserPlaylists(ctx.user.id);
    }),

    /**
     * Get playlist with songs
     */
    getWithSongs: publicProcedure
      .input(z.object({ playlistId: z.number() }))
      .query(async ({ input }) => {
        return getPlaylistWithSongs(input.playlistId);
      }),

    /**
     * Add song to playlist
     */
    addSong: protectedProcedure
      .input(z.object({ playlistId: z.number(), musicId: z.number(), position: z.number() }))
      .mutation(async ({ input, ctx }) => {
        // Verify ownership
        const playlists = await getUserPlaylists(ctx.user.id);
        const ownsPlaylist = playlists.some((p) => p.id === input.playlistId);
        if (!ownsPlaylist) throw new Error("Unauthorized");

        return addSongToPlaylist(input.playlistId, input.musicId, input.position);
      }),

    /**
     * Remove song from playlist
     */
    removeSong: protectedProcedure
      .input(z.object({ playlistId: z.number(), musicId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        // Verify ownership
        const playlists = await getUserPlaylists(ctx.user.id);
        const ownsPlaylist = playlists.some((p) => p.id === input.playlistId);
        if (!ownsPlaylist) throw new Error("Unauthorized");

        return removeSongFromPlaylist(input.playlistId, input.musicId);
      }),

    /**
     * Delete a playlist
     */
    delete: protectedProcedure
      .input(z.object({ playlistId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        return deletePlaylist(input.playlistId, ctx.user.id);
      }),

    /**
     * Play playlist (increment play count)
     */
    play: publicProcedure
      .input(z.object({ playlistId: z.number() }))
      .mutation(async ({ input }) => {
        return incrementPlaylistPlays(input.playlistId);
      }),
  }),
});
