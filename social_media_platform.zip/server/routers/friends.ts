/**
 * Friends Router - tRPC procedures for friends system
 */

import { z } from "zod";
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";
import {
  sendFriendRequest,
  acceptFriendRequest,
  rejectFriendRequest,
  getPendingRequests,
  getFriendsList,
  getFriendSuggestions,
  getMutualFriends,
  blockUser,
  unblockUser,
  getBlockedUsers,
} from "../friends";

export const friendsRouter = router({
  /**
   * Send a friend request
   */
  sendRequest: protectedProcedure
    .input(z.object({ receiverId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      return sendFriendRequest(ctx.user.id, input.receiverId);
    }),

  /**
   * Accept a friend request
   */
  acceptRequest: protectedProcedure
    .input(z.object({ requestId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      return acceptFriendRequest(input.requestId, ctx.user.id);
    }),

  /**
   * Reject a friend request
   */
  rejectRequest: protectedProcedure
    .input(z.object({ requestId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      return rejectFriendRequest(input.requestId, ctx.user.id);
    }),

  /**
   * Get pending friend requests
   */
  getPending: protectedProcedure.query(async ({ ctx }) => {
    return getPendingRequests(ctx.user.id);
  }),

  /**
   * Get friends list
   */
  getList: protectedProcedure
    .input(z.object({ userId: z.number().optional() }))
    .query(async ({ input, ctx }) => {
      const userId = input.userId || ctx.user.id;
      return getFriendsList(userId);
    }),

  /**
   * Get friend suggestions
   */
  getSuggestions: protectedProcedure
    .input(z.object({ limit: z.number().default(10) }))
    .query(async ({ input, ctx }) => {
      return getFriendSuggestions(ctx.user.id, input.limit);
    }),

  /**
   * Get mutual friends with another user
   */
  getMutual: protectedProcedure
    .input(z.object({ userId: z.number() }))
    .query(async ({ input, ctx }) => {
      return getMutualFriends(ctx.user.id, input.userId);
    }),

  /**
   * Block a user
   */
  block: protectedProcedure
    .input(z.object({ userId: z.number(), reason: z.string().optional() }))
    .mutation(async ({ input, ctx }) => {
      return blockUser(ctx.user.id, input.userId, input.reason);
    }),

  /**
   * Unblock a user
   */
  unblock: protectedProcedure
    .input(z.object({ userId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      return unblockUser(ctx.user.id, input.userId);
    }),

  /**
   * Get blocked users list
   */
  getBlocked: protectedProcedure.query(async ({ ctx }) => {
    return getBlockedUsers(ctx.user.id);
  }),
});
