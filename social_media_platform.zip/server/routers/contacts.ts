import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { findUsersByContacts, searchUsersByQuery } from "../contacts";

export const contactsRouter = router({
  /**
   * Find users by imported contacts (phone/email)
   */
  findByContacts: protectedProcedure
    .input(
      z.object({
        contacts: z.array(
          z.object({
            phone: z.string().optional(),
            email: z.string().email().optional(),
          })
        ),
      })
    )
    .mutation(async ({ input }) => {
      const users = await findUsersByContacts(input.contacts);
      return { users };
    }),

  /**
   * Search users by query string
   */
  search: protectedProcedure
    .input(
      z.object({
        query: z.string().min(1),
        limit: z.number().min(1).max(50).default(20),
      })
    )
    .query(async ({ input }) => {
      const users = await searchUsersByQuery(input.query, input.limit);
      return users;
    }),
});
