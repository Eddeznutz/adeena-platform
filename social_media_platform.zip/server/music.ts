/**
 * Music System Database Helpers
 * Handles music uploads, streaming, playlists, and likes
 */

import { eq, and, or, desc } from "drizzle-orm";
import { getDb } from "./db";
import { music, playlists, playlistSongs, musicLikes, users } from "../drizzle/schema";

/**
 * Upload a new music track
 */
export async function uploadMusic(
  userId: number,
  title: string,
  musicUrl: string,
  artist?: string,
  album?: string,
  genre?: string,
  description?: string,
  coverUrl?: string,
  duration?: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(music).values({
    userId,
    title,
    musicUrl,
    artist,
    album,
    genre,
    description,
    coverUrl,
    duration,
    isPublic: 1,
  });

  return { success: true, id: result[0].insertId };
}

/**
 * Get music tracks by user
 */
export async function getUserMusic(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const tracks = await db
    .select()
    .from(music)
    .where(eq(music.userId, userId));

  return tracks;
}

/**
 * Get all public music tracks
 */
export async function getPublicMusic(limit: number = 50, offset: number = 0) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const tracks = await db
    .select()
    .from(music)
    .where(eq(music.isPublic, 1))
    .orderBy(desc(music.createdAt))
    .limit(limit)
    .offset(offset);

  return tracks;
}

/**
 * Get music by ID
 */
export async function getMusicById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const track = await db.select().from(music).where(eq(music.id, id)).limit(1);

  return track.length > 0 ? track[0] : null;
}

/**
 * Search music by title, artist, or album
 */
export async function searchMusic(query: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const results = await db
    .select()
    .from(music)
    .where(
      and(
        eq(music.isPublic, 1),
        or(
          // @ts-ignore
          db.sql`LOWER(${music.title}) LIKE LOWER(${`%${query}%`})`,
          // @ts-ignore
          db.sql`LOWER(${music.artist}) LIKE LOWER(${`%${query}%`})`,
          // @ts-ignore
          db.sql`LOWER(${music.album}) LIKE LOWER(${`%${query}%`})`
        )
      )
    );

  return results;
}

/**
 * Increment play count for a music track
 */
export async function incrementMusicPlays(musicId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const track = await getMusicById(musicId);
  if (!track) throw new Error("Music not found");

  await db
    .update(music)
    .set({ plays: track.plays + 1 })
    .where(eq(music.id, musicId));

  return { success: true };
}

/**
 * Like a music track
 */
export async function likeMusicTrack(userId: number, musicId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Check if already liked
  const existing = await db
    .select()
    .from(musicLikes)
    .where(and(eq(musicLikes.userId, userId), eq(musicLikes.musicId, musicId)))
    .limit(1);

  if (existing.length > 0) {
    throw new Error("Already liked this track");
  }

  const track = await getMusicById(musicId);
  if (!track) throw new Error("Music not found");

  await db.insert(musicLikes).values({ userId, musicId });

  await db
    .update(music)
    .set({ likes: track.likes + 1 })
    .where(eq(music.id, musicId));

  return { success: true };
}

/**
 * Unlike a music track
 */
export async function unlikeMusicTrack(userId: number, musicId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const track = await getMusicById(musicId);
  if (!track) throw new Error("Music not found");

  await db
    .delete(musicLikes)
    .where(and(eq(musicLikes.userId, userId), eq(musicLikes.musicId, musicId)));

  await db
    .update(music)
    .set({ likes: Math.max(0, track.likes - 1) })
    .where(eq(music.id, musicId));

  return { success: true };
}

/**
 * Get user's liked music tracks
 */
export async function getUserLikedMusic(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const likedTracks = await db
    .select({
      id: music.id,
      title: music.title,
      artist: music.artist,
      album: music.album,
      musicUrl: music.musicUrl,
      coverUrl: music.coverUrl,
      duration: music.duration,
      plays: music.plays,
      likes: music.likes,
    })
    .from(musicLikes)
    .innerJoin(music, eq(musicLikes.musicId, music.id))
    .where(eq(musicLikes.userId, userId));

  return likedTracks;
}

/**
 * Create a new playlist
 */
export async function createPlaylist(
  userId: number,
  name: string,
  description?: string,
  coverUrl?: string,
  isPublic: number = 1
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(playlists).values({
    userId,
    name,
    description,
    coverUrl,
    isPublic,
  });

  return { success: true, id: result[0].insertId };
}

/**
 * Get user's playlists
 */
export async function getUserPlaylists(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const userPlaylists = await db
    .select()
    .from(playlists)
    .where(eq(playlists.userId, userId));

  return userPlaylists;
}

/**
 * Get playlist by ID with songs
 */
export async function getPlaylistWithSongs(playlistId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const playlist = await db
    .select()
    .from(playlists)
    .where(eq(playlists.id, playlistId))
    .limit(1);

  if (playlist.length === 0) throw new Error("Playlist not found");

  const songs = await db
    .select({
      id: music.id,
      title: music.title,
      artist: music.artist,
      album: music.album,
      musicUrl: music.musicUrl,
      coverUrl: music.coverUrl,
      duration: music.duration,
      position: playlistSongs.position,
    })
    .from(playlistSongs)
    .innerJoin(music, eq(playlistSongs.musicId, music.id))
    .where(eq(playlistSongs.playlistId, playlistId))
    .orderBy(playlistSongs.position);

  return { ...playlist[0], songs };
}

/**
 * Add song to playlist
 */
export async function addSongToPlaylist(playlistId: number, musicId: number, position: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Check if already in playlist
  const existing = await db
    .select()
    .from(playlistSongs)
    .where(
      and(eq(playlistSongs.playlistId, playlistId), eq(playlistSongs.musicId, musicId))
    )
    .limit(1);

  if (existing.length > 0) {
    throw new Error("Song already in playlist");
  }

  await db.insert(playlistSongs).values({
    playlistId,
    musicId,
    position,
  });

  return { success: true };
}

/**
 * Remove song from playlist
 */
export async function removeSongFromPlaylist(playlistId: number, musicId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db
    .delete(playlistSongs)
    .where(
      and(eq(playlistSongs.playlistId, playlistId), eq(playlistSongs.musicId, musicId))
    );

  return { success: true };
}

/**
 * Delete a playlist
 */
export async function deletePlaylist(playlistId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const playlist = await db
    .select()
    .from(playlists)
    .where(eq(playlists.id, playlistId))
    .limit(1);

  if (playlist.length === 0) throw new Error("Playlist not found");
  if (playlist[0].userId !== userId) throw new Error("Unauthorized");

  // Delete all songs in playlist
  await db.delete(playlistSongs).where(eq(playlistSongs.playlistId, playlistId));

  // Delete playlist
  await db.delete(playlists).where(eq(playlists.id, playlistId));

  return { success: true };
}

/**
 * Increment playlist play count
 */
export async function incrementPlaylistPlays(playlistId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const playlist = await db
    .select()
    .from(playlists)
    .where(eq(playlists.id, playlistId))
    .limit(1);

  if (playlist.length === 0) throw new Error("Playlist not found");

  await db
    .update(playlists)
    .set({ plays: playlist[0].plays + 1 })
    .where(eq(playlists.id, playlistId));

  return { success: true };
}

/**
 * Get trending music (most played)
 */
export async function getTrendingMusic(limit: number = 20) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const trending = await db
    .select()
    .from(music)
    .where(eq(music.isPublic, 1))
    .orderBy(desc(music.plays))
    .limit(limit);

  return trending;
}

/**
 * Get music by genre
 */
export async function getMusicByGenre(genre: string, limit: number = 20) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const genreMusic = await db
    .select()
    .from(music)
    .where(and(eq(music.isPublic, 1), eq(music.genre, genre)))
    .orderBy(desc(music.createdAt))
    .limit(limit);

  return genreMusic;
}

/**
 * Get music by artist
 */
export async function getMusicByArtist(artist: string, limit: number = 20) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const artistMusic = await db
    .select()
    .from(music)
    .where(and(eq(music.isPublic, 1), eq(music.artist, artist)))
    .orderBy(desc(music.createdAt))
    .limit(limit);

  return artistMusic;
}

/**
 * Increment music download count
 */
export async function incrementMusicDownloads(musicId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const track = await getMusicById(musicId);
  if (!track) throw new Error("Music not found");

  await db
    .update(music)
    .set({ downloads: track.downloads + 1 })
    .where(eq(music.id, musicId));

  return { success: true };
}
