/**
 * Adeena Service Worker
 * Enables offline functionality and caching for PWA
 */

const CACHE_NAME = "adeena-v1";
const RUNTIME_CACHE = "adeena-runtime";
const ASSETS_TO_CACHE = [
  "/",
  "/index.html",
  "/manifest.json",
];

/**
 * Install event - cache essential assets
 */
self.addEventListener("install", (event) => {
  console.log("[Service Worker] Installing...");
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log("[Service Worker] Caching essential assets");
      return cache.addAll(ASSETS_TO_CACHE);
    })
  );
  self.skipWaiting();
});

/**
 * Activate event - clean up old caches
 */
self.addEventListener("activate", (event) => {
  console.log("[Service Worker] Activating...");
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME && cacheName !== RUNTIME_CACHE) {
            console.log("[Service Worker] Deleting old cache:", cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
  self.clients.claim();
});

/**
 * Fetch event - serve from cache, fallback to network
 */
self.addEventListener("fetch", (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Skip non-GET requests
  if (request.method !== "GET") {
    return;
  }

  // Skip API calls - always go to network
  if (url.pathname.startsWith("/api/")) {
    event.respondWith(
      fetch(request)
        .then((response) => {
          // Cache successful API responses
          if (response.ok) {
            const cache = caches.open(RUNTIME_CACHE);
            cache.then((c) => c.put(request, response.clone()));
          }
          return response;
        })
        .catch(() => {
          // Return cached response if network fails
          return caches.match(request);
        })
    );
    return;
  }

  // For static assets, use cache-first strategy
  event.respondWith(
    caches.match(request).then((response) => {
      if (response) {
        return response;
      }

      return fetch(request).then((response) => {
        // Cache successful responses
        if (!response || response.status !== 200 || response.type === "error") {
          return response;
        }

        const responseToCache = response.clone();
        caches.open(RUNTIME_CACHE).then((cache) => {
          cache.put(request, responseToCache);
        });

        return response;
      });
    })
  );
});

/**
 * Handle messages from clients
 */
self.addEventListener("message", (event) => {
  if (event.data && event.data.type === "SKIP_WAITING") {
    self.skipWaiting();
  }

  if (event.data && event.data.type === "CLEAR_CACHE") {
    caches.delete(RUNTIME_CACHE).then(() => {
      console.log("[Service Worker] Runtime cache cleared");
    });
  }
});

/**
 * Background sync for offline actions
 */
self.addEventListener("sync", (event) => {
  if (event.tag === "sync-messages") {
    event.waitUntil(syncMessages());
  }
  if (event.tag === "sync-videos") {
    event.waitUntil(syncVideos());
  }
});

/**
 * Sync pending messages when back online
 */
async function syncMessages() {
  try {
    const cache = await caches.open(RUNTIME_CACHE);
    const requests = await cache.keys();
    const messageRequests = requests.filter((req) =>
      req.url.includes("/api/trpc/messages.send")
    );

    for (const request of messageRequests) {
      try {
        await fetch(request);
        await cache.delete(request);
      } catch (error) {
        console.error("[Service Worker] Failed to sync message:", error);
      }
    }
  } catch (error) {
    console.error("[Service Worker] Sync messages failed:", error);
  }
}

/**
 * Sync pending video uploads when back online
 */
async function syncVideos() {
  try {
    const cache = await caches.open(RUNTIME_CACHE);
    const requests = await cache.keys();
    const videoRequests = requests.filter((req) =>
      req.url.includes("/api/trpc/videos.upload")
    );

    for (const request of videoRequests) {
      try {
        await fetch(request);
        await cache.delete(request);
      } catch (error) {
        console.error("[Service Worker] Failed to sync video:", error);
      }
    }
  } catch (error) {
    console.error("[Service Worker] Sync videos failed:", error);
  }
}

console.log("[Service Worker] Loaded successfully");
