# Content Policy & Community Guidelines

**Last Updated: November 2025**

## 1. Overview

Adeena is committed to maintaining a safe, respectful, and inclusive community. This Content Policy outlines what content is and is not permitted on our platform.

## 2. Prohibited Content

### 2.1 Illegal Content
We prohibit content that violates any applicable law, including:
- Child sexual abuse material (CSAM)
- Human trafficking or exploitation
- Sale of illegal drugs or controlled substances
- Weapons trafficking or illegal arms sales
- Terrorism or violent extremism
- Fraud or financial crimes
- Copyright or trademark infringement

### 2.2 Harmful & Dangerous Content
We prohibit content that promotes harm, including:
- Violence or threats of violence
- Self-harm or suicide promotion
- Eating disorders or dangerous health practices
- Dangerous challenges or stunts
- Abuse of animals
- Harassment or bullying
- Hate speech or discrimination based on protected characteristics

### 2.3 Sexual & Exploitative Content
We prohibit:
- Nude or sexually explicit content
- Sexual exploitation or abuse
- Non-consensual intimate images
- Sexualization of minors
- Prostitution or sex trafficking
- Incest content

### 2.4 Misinformation & Manipulation
We prohibit:
- Deliberately false health information
- Election misinformation
- Manipulated media presented as real
- Conspiracy theories promoting harm
- Scams or fraudulent schemes
- Impersonation or identity fraud

### 2.5 Spam & Manipulation
We prohibit:
- Spam or repetitive posting
- Artificial engagement manipulation
- Bot networks or fake accounts
- Phishing or credential harvesting
- Malware distribution
- Unauthorized commercial promotion

### 2.6 Privacy Violations
We prohibit:
- Sharing private information without consent
- Doxing (publishing private information)
- Non-consensual sharing of intimate images
- Unauthorized surveillance or recording
- Stalking or harassment

## 3. Content That Requires Warnings

The following content is permitted but may require age-appropriate warnings or restrictions:

- Graphic violence or gore
- Profanity or strong language
- Mature themes or sexual content (non-explicit)
- Alcohol or tobacco use
- Gambling content
- Political content
- Religious or ideological content

## 4. Enforcement & Consequences

### 4.1 Warning
First violation may result in a warning and content removal.

### 4.2 Temporary Suspension
Repeated violations may result in temporary account suspension (24 hours to 30 days).

### 4.3 Permanent Ban
Severe violations or repeated offenses may result in permanent account termination.

### 4.4 Legal Action
Illegal content will be reported to appropriate authorities.

## 5. Reporting Violations

### 5.1 How to Report
Users can report violations through:
- In-app reporting button on content
- Report user profile feature
- Email: report@adeena.com
- Emergency: contact@adeena.com

### 5.2 What to Include
- Description of the violation
- Link to the content (if applicable)
- Screenshots or evidence
- Your contact information

### 5.3 Response Time
We aim to review reports within 24-48 hours and take action if warranted.

## 6. Appeals

If your content was removed or your account suspended, you can appeal:
- Submit appeal through account settings
- Include explanation and any additional context
- Appeals reviewed within 5-7 business days
- Final decision is binding

## 7. Copyright & Intellectual Property

### 7.1 Respect IP Rights
Do not upload content that:
- Infringes copyrights
- Violates trademarks
- Uses others' creative work without permission
- Misrepresents authorship

### 7.2 Fair Use
Limited use of copyrighted material may be permitted for:
- Commentary or criticism
- Educational purposes
- Parody or satire
- Transformative works

### 7.3 DMCA Takedowns
Copyright holders can submit DMCA notices. See our DMCA Policy for details.

## 8. Monetization & Sponsored Content

### 8.1 Transparency
Sponsored content must be clearly labeled as:
- #ad or #sponsored
- Paid promotion
- Brand partnership

### 8.2 Prohibited Practices
- Misleading endorsements
- Undisclosed affiliate links
- Deceptive advertising
- Predatory marketing

## 9. Exceptions for News & Journalism

Content that would otherwise violate this policy may be permitted if:
- It's newsworthy or in the public interest
- It's presented in journalistic context
- It includes appropriate warnings
- It's not gratuitously graphic

## 10. Community Standards

We encourage:
- Respectful disagreement
- Diverse perspectives
- Constructive criticism
- Supporting other creators
- Reporting violations

We discourage:
- Personal attacks
- Toxic behavior
- Harassment campaigns
- Coordinated abuse
- Bad faith arguments

## 11. Special Protections

### 11.1 Minors
Content involving minors receives enhanced protection:
- Stricter enforcement of sexual content policies
- Enhanced privacy protections
- Parental consent requirements where applicable
- Age-appropriate content recommendations

### 11.2 Vulnerable Groups
We provide additional protections for:
- Victims of abuse or trafficking
- People with disabilities
- Marginalized communities
- People in crisis

## 12. Policy Updates

We may update this policy at any time. Significant changes will be announced. Continued use of Adeena constitutes acceptance of updated policies.

## 13. Contact & Support

For questions about content policies:
- Email: support@adeena.com
- In-app support chat
- Help center: adeena.com/help

---

**By using Adeena, you agree to follow these Community Guidelines and Content Policies.**
