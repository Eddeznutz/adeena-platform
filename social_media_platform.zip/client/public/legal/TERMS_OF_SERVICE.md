# Terms of Service

**Last Updated: November 2025**

## 1. Acceptance of Terms

By accessing and using Adeena ("Service"), you accept and agree to be bound by the terms and provision of this agreement. If you do not agree to abide by the above, please do not use this service.

## 2. Use License

Permission is granted to temporarily download one copy of the materials (information or software) on Adeena for personal, non-commercial transitory viewing only. This is the grant of a license, not a transfer of title, and under this license you may not:

- Modifying or copying the materials
- Using the materials for any commercial purpose or for any public display
- Attempting to decompile or reverse engineer any software contained on Adeena
- Removing any copyright or other proprietary notations from the materials
- Transferring the materials to another person or "mirroring" the materials on any other server
- Violating any applicable laws or regulations

## 3. Disclaimer

The materials on Adeena are provided on an 'as is' basis. Adeena makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties including, without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights.

## 4. Limitations

In no event shall Adeena or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the materials on Adeena, even if Adeena or an authorized representative has been notified orally or in writing of the possibility of such damage.

## 5. Accuracy of Materials

The materials appearing on Adeena could include technical, typographical, or photographic errors. Adeena does not warrant that any of the materials on its website are accurate, complete, or current. Adeena may make changes to the materials contained on its website at any time without notice.

## 6. Materials Liability

Adeena has not reviewed all of the sites linked to its website and is not responsible for the contents of any such linked site. The inclusion of any link does not imply endorsement by Adeena of the site. Use of any such linked website is at the user's own risk.

## 7. Modifications

Adeena may revise these terms of service for its website at any time without notice. By using this website, you are agreeing to be bound by the then current version of these terms of service.

## 8. Governing Law

These terms and conditions are governed by and construed in accordance with the laws of the United States, and you irrevocably submit to the exclusive jurisdiction of the courts in that location.

## 9. User-Generated Content

### 9.1 Your Responsibility
You are solely responsible for any content you upload, post, or transmit through Adeena, including but not limited to videos, messages, comments, and profiles. You warrant that you own or have the necessary rights to all content you post.

### 9.2 Prohibited Content
You agree not to post content that:
- Is illegal or violates any applicable law
- Infringes on intellectual property rights
- Contains hate speech, harassment, or threats
- Is sexually explicit or exploitative
- Contains malware or harmful code
- Is spam or misleading
- Violates privacy or confidentiality
- Incites violence or illegal activity

### 9.3 Content Removal
Adeena reserves the right to remove any content that violates these terms without notice. Repeated violations may result in account suspension or termination.

### 9.4 No Liability for User Content
Adeena is not responsible for user-generated content. Users post content at their own risk and are solely responsible for any consequences arising from their posts.

## 10. Account Termination

Adeena reserves the right to terminate or suspend any account at any time for violations of these terms or for any other reason at its sole discretion. Upon termination, your right to use the Service will immediately cease.

## 11. Copyright & Intellectual Property

All content on Adeena, including but not limited to text, graphics, logos, images, and software, is the property of Adeena or its content suppliers and is protected by international copyright laws. You may not reproduce, distribute, or transmit any content without permission.

## 12. Third-Party Services

Adeena uses third-party services including but not limited to payment processors (Stripe), analytics, and hosting providers. These services are subject to their own terms and privacy policies.

## 13. DMCA Compliance

Adeena respects intellectual property rights. If you believe your copyright has been infringed, please submit a DMCA notice to our designated agent. See our DMCA Policy for details.

## 14. Age Restrictions

Adeena is intended for users 13 years and older. Users under 13 are not permitted to use this Service. We comply with COPPA (Children's Online Privacy Protection Act) and similar regulations worldwide.

## 15. Indemnification

You agree to indemnify, defend, and hold harmless Adeena, its officers, directors, employees, and agents from any and all claims, damages, losses, liabilities, and expenses (including reasonable attorneys' fees) arising out of your use of the Service or violation of these terms.

## 16. Severability

If any provision of these terms is found to be invalid or unenforceable, the remaining provisions shall continue in full force and effect.

## 17. Entire Agreement

These terms of service constitute the entire agreement between you and Adeena regarding the use of the Service and supersede all prior agreements and understandings.

## 18. Contact Information

For questions about these Terms of Service, please contact us at: legal@adeena.com

---

**By using Adeena, you acknowledge that you have read, understood, and agree to be bound by these Terms of Service.**
