# Privacy Policy

**Last Updated: November 2025**

## 1. Introduction

Adeena ("we," "us," "our," or "Company") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our website and services.

This policy complies with:
- GDPR (General Data Protection Regulation) - EU
- CCPA (California Consumer Privacy Act) - USA
- LGPD (Lei Geral de Proteção de Dados) - Brazil
- PIPEDA (Personal Information Protection and Electronic Documents Act) - Canada
- And similar regulations worldwide

## 2. Information We Collect

### 2.1 Information You Provide
- **Account Information**: Name, email, username, password
- **Profile Information**: Bio, profile picture, location, interests
- **Content**: Videos, messages, comments, posts
- **Payment Information**: Processed securely through Stripe (we don't store credit card details)
- **Communications**: Messages, support requests, feedback

### 2.2 Information Collected Automatically
- **Device Information**: Device type, operating system, browser type
- **Usage Information**: Pages visited, time spent, features used, clicks
- **Location Information**: IP address, approximate location (with permission)
- **Cookies & Tracking**: Analytics, preferences, session data
- **Log Data**: Server logs, error reports, performance data

### 2.3 Information from Third Parties
- **OAuth Providers**: Authentication data from Manus OAuth
- **Payment Processors**: Transaction information from Stripe
- **Analytics**: Aggregated usage data
- **Third-Party Services**: Data from integrated services

## 3. How We Use Your Information

We use collected information for:
- Providing and improving the Service
- Personalizing your experience
- Processing payments and subscriptions
- Sending notifications and updates
- Responding to inquiries and support requests
- Analyzing usage patterns and trends
- Detecting and preventing fraud
- Complying with legal obligations
- Marketing (with your consent)

## 4. Legal Basis for Processing (GDPR)

We process your information based on:
- **Consent**: You've explicitly agreed (e.g., marketing emails)
- **Contract**: Necessary to provide the Service
- **Legal Obligation**: Required by law
- **Legitimate Interest**: Our business interests (e.g., security, fraud prevention)
- **Vital Interest**: Protecting your health or safety

## 5. Data Sharing

We share information with:
- **Service Providers**: Stripe (payments), hosting providers, analytics services
- **Legal Authorities**: When required by law or to protect rights
- **Business Partners**: Only with your consent
- **Other Users**: Public content is visible to all users
- **Aggregated Data**: Non-identifying statistical information

We do NOT sell your personal information to third parties.

## 6. Data Retention

- **Account Data**: Retained while you have an account, deleted upon request
- **Content**: Retained until deleted by you or account termination
- **Messages**: Encrypted and retained per your settings
- **Logs**: Retained for 90 days for security purposes
- **Payment Records**: Retained for 7 years (legal requirement)

## 7. Your Rights

### 7.1 GDPR Rights (EU Users)
- Right to access your data
- Right to rectification (correct inaccurate data)
- Right to erasure ("right to be forgotten")
- Right to restrict processing
- Right to data portability
- Right to object to processing
- Right to withdraw consent
- Right to lodge a complaint with authorities

### 7.2 CCPA Rights (California Users)
- Right to know what data is collected
- Right to delete personal information
- Right to opt-out of data sales
- Right to non-discrimination for exercising rights

### 7.3 LGPD Rights (Brazil Users)
- Right to access, correct, delete personal data
- Right to data portability
- Right to withdraw consent
- Right to lodge complaints

### 7.4 How to Exercise Rights
Contact us at: privacy@adeena.com with your request. We'll respond within 30 days.

## 8. Data Security

We implement:
- **Encryption**: SSL/TLS for data in transit, AES-256 for sensitive data at rest
- **Access Controls**: Role-based permissions, authentication
- **Monitoring**: Continuous security monitoring and logging
- **Regular Audits**: Security assessments and penetration testing
- **Incident Response**: Procedures for data breaches
- **Employee Training**: Security awareness for all staff

However, no system is 100% secure. We cannot guarantee absolute security.

## 9. Children's Privacy (COPPA Compliance)

- Adeena is intended for users 13 and older
- We do not knowingly collect data from children under 13
- If we discover we've collected data from a child under 13, we'll delete it immediately
- For users 13-17, we provide enhanced privacy protections
- Parents/guardians can request data deletion for minors

## 10. International Data Transfers

Your data may be transferred to and processed in countries other than your country of residence. These countries may have data protection laws different from your home country. By using Adeena, you consent to such transfers.

We implement Standard Contractual Clauses (SCCs) to protect international transfers.

## 11. Cookies & Tracking

We use:
- **Essential Cookies**: Required for functionality
- **Performance Cookies**: Analytics and optimization
- **Preference Cookies**: Remembering your settings
- **Marketing Cookies**: Personalized ads (with consent)

You can control cookies through your browser settings. Disabling cookies may affect functionality.

## 12. Third-Party Links

Adeena may contain links to third-party websites. We're not responsible for their privacy practices. Please review their privacy policies.

## 13. California Privacy Rights (CCPA)

California residents have specific rights:
- Right to know what personal information is collected
- Right to know whether personal information is sold or disclosed
- Right to delete personal information collected
- Right to opt-out of the sale of personal information
- Right to non-discrimination for exercising CCPA rights

To exercise these rights, contact: privacy@adeena.com

## 14. EU Representative

For GDPR inquiries, our EU representative is:
Adeena Legal Team
Email: privacy@adeena.com

## 15. Data Breach Notification

In the event of a data breach, we will:
- Notify affected users without undue delay
- Notify relevant authorities as required by law
- Provide information about the breach and steps to protect yourself
- Maintain a breach log for regulatory compliance

## 16. Policy Changes

We may update this Privacy Policy. Changes will be posted with an updated "Last Updated" date. Continued use of Adeena constitutes acceptance of changes.

## 17. Contact Information

For privacy questions or to exercise your rights:

**Email**: privacy@adeena.com
**Mailing Address**: Adeena Legal Department
**Response Time**: 30 days

---

**By using Adeena, you acknowledge that you have read and understood this Privacy Policy.**
