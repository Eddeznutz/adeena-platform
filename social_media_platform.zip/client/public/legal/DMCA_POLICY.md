# DMCA Policy & Copyright Procedures

**Last Updated: November 2025**

## 1. Copyright Compliance

Adeena respects intellectual property rights and complies with the Digital Millennium Copyright Act (DMCA). We respond promptly to valid copyright infringement claims.

## 2. Designated Copyright Agent

Our designated DMCA agent is:

**Adeena Legal Department**
Email: dmca@adeena.com
Mailing Address: Adeena Legal Team
Response Time: 24-48 hours

## 3. DMCA Takedown Notice

### 3.1 How to Submit

If you believe your copyrighted work has been infringed, submit a written notice containing:

1. **Your Information**
   - Your name and contact information
   - Email and phone number
   - Mailing address

2. **Identification of Copyrighted Work**
   - Description of the copyrighted work
   - URL or location of the original work
   - Proof of copyright ownership

3. **Identification of Infringing Content**
   - Specific URL(s) of infringing content on Adeena
   - Description of how content infringes your copyright
   - Explanation of why this is not fair use

4. **Your Statement**
   - Statement that you have a good faith belief the use is unauthorized
   - Statement under penalty of perjury that information is accurate
   - Statement that you are authorized to act on behalf of the copyright holder

5. **Your Signature**
   - Physical or digital signature

### 3.2 Submission Method

Email your notice to: dmca@adeena.com

Include "[DMCA NOTICE]" in the subject line.

## 4. Our Response

Upon receipt of a valid DMCA notice, we will:

1. **Verify** the notice contains all required information
2. **Investigate** the claim
3. **Remove** or disable access to infringing content
4. **Notify** the user who posted the content
5. **Document** the takedown for our records

We aim to respond within 24-48 hours.

## 5. Counter-Notice

If your content was removed due to a DMCA notice, you may submit a counter-notice if you believe:
- The content does not infringe copyright
- The copyright holder made a mistake
- Fair use applies to your use

### 5.1 Counter-Notice Requirements

Your counter-notice must include:

1. **Your Information**
   - Full name and contact information
   - Email and phone number
   - Mailing address

2. **Identification of Content**
   - Specific URL(s) of removed content
   - Description of the content

3. **Your Statement**
   - Statement that you have good faith belief the removal was erroneous
   - Explanation of why the use is not infringing
   - Explanation of fair use if applicable

4. **Your Signature**
   - Physical or digital signature

5. **Consent to Jurisdiction**
   - Agreement to submit to jurisdiction of federal court

### 5.2 Submitting Counter-Notice

Email to: dmca@adeena.com

Include "[DMCA COUNTER-NOTICE]" in the subject line.

## 6. Counter-Notice Process

Upon receipt of a valid counter-notice:

1. We notify the copyright claimant
2. The claimant has 10 business days to file a lawsuit
3. If no lawsuit is filed, we restore the content
4. If a lawsuit is filed, content remains disabled pending court decision

## 7. Repeat Infringers

Users who repeatedly infringe copyrights may have their accounts suspended or terminated. We maintain records of DMCA notices and takedowns.

## 8. Limitations

Adeena is not responsible for:
- Monitoring content for copyright infringement
- Determining fair use or other defenses
- Disputes between users and copyright holders
- Content posted by third parties

## 9. False Claims

Submitting false DMCA notices is illegal and may result in:
- Legal liability for damages
- Criminal penalties
- Account termination
- Reporting to law enforcement

## 10. Fair Use Considerations

Fair use may apply to uses including:
- Commentary or criticism
- Educational purposes
- News reporting
- Parody or satire
- Transformative works

However, fair use is determined case-by-case and is not automatic.

## 11. Other IP Rights

This policy applies to copyright. For other intellectual property issues (trademarks, patents, etc.), contact: legal@adeena.com

## 12. Contact Information

**DMCA Notices**: dmca@adeena.com
**General Legal**: legal@adeena.com
**Support**: support@adeena.com

---

**By using Adeena, you agree to comply with this DMCA Policy and all applicable copyright laws.**
