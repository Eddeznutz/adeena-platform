import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Heart, MessageCircle, Share2, Eye } from "lucide-react";
import { VideoPlayer } from "@/components/VideoPlayer";
import { useState } from "react";
import { useLocation } from "wouter";

export default function Feed() {
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const { data: videos, isLoading } = trpc.videos.list.useQuery({ limit: 50 });
  const [likedVideos, setLikedVideos] = useState<number[]>([]);

  const toggleLikeMutation = trpc.likes.toggle.useMutation({
    onSuccess: (result, input) => {
      if (result.liked) {
        setLikedVideos((prev) => [...prev, input.videoId]);
      } else {
        setLikedVideos((prev) => prev.filter((id) => id !== input.videoId));
      }
    },
  });

  const handleLike = (videoId: number) => {
    if (!isAuthenticated) {
      setLocation("/");
      return;
    }
    toggleLikeMutation.mutate({ videoId });
  };

  if (isLoading) {
    return (
      <div className="container py-8">
        <div className="text-center text-muted-foreground">Loading videos...</div>
      </div>
    );
  }

  if (!videos || videos.length === 0) {
    return (
      <div className="container py-8">
        <div className="text-center text-muted-foreground">No videos yet. Be the first to upload!</div>
      </div>
    );
  }

  return (
    <div className="container py-8">
      <div className="max-w-2xl mx-auto space-y-6">
        <h1 className="text-3xl font-bold mb-8">Video Feed</h1>
        
        {videos.map((video) => (
          <Card key={video.id} className="overflow-hidden hover:shadow-lg transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-lg">{video.title}</h3>
                  <p className="text-sm text-muted-foreground">
                    {new Date(video.createdAt).toLocaleDateString()}
                  </p>
                </div>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-4">
              {/* Video Player */}
              {video.videoUrl && (
                <VideoPlayer
                  src={video.videoUrl}
                  poster={video.thumbnailUrl || undefined}
                  className="w-full aspect-video"
                />
              )}
              
              {video.description && (
                <p className="text-sm text-foreground">{video.description}</p>
              )}

              {/* Video Stats */}
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-1">
                  <Eye className="w-4 h-4" />
                  <span>{video.views} views</span>
                </div>
                <div className="flex items-center gap-1">
                  <Heart className="w-4 h-4" />
                  <span>{video.likes} likes</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2 pt-4 border-t">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleLike(video.id)}
                  className={likedVideos.includes(video.id) ? "text-red-500" : ""}
                >
                  <Heart
                    className={`w-4 h-4 mr-2 ${
                      likedVideos.includes(video.id) ? "fill-red-500" : ""
                    }`}
                  />
                  {likedVideos.includes(video.id) ? "Liked" : "Like"}
                </Button>
                <Button variant="ghost" size="sm">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Comment
                </Button>
                <Button variant="ghost" size="sm">
                  <Share2 className="w-4 h-4 mr-2" />
                  Share
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
