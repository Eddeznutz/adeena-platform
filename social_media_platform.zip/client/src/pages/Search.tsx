import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search as SearchIcon, Eye, Heart } from "lucide-react";

export default function Search() {
  const [location] = useLocation();
  const params = new URLSearchParams(location.split("?")[1]);
  const initialQuery = params.get("q") || "";
  const [query, setQuery] = useState(initialQuery);

  const { data: results, isLoading } = trpc.search.all.useQuery(
    { query },
    { enabled: query.length > 0 }
  );

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      // The query state change will trigger the useQuery
    }
  };

  return (
    <div className="container py-8">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Search Bar */}
        <form onSubmit={handleSearch} className="space-y-4">
          <div className="relative">
            <Input
              type="text"
              placeholder="Search videos, users, hashtags..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="pl-10 text-lg h-12"
              autoFocus
            />
            <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          </div>
        </form>

        {/* Results */}
        {isLoading ? (
          <div className="text-center text-muted-foreground">Searching...</div>
        ) : query.length === 0 ? (
          <div className="text-center text-muted-foreground">
            Enter a search query to find videos and users
          </div>
        ) : !results || (results.videos.length === 0 && results.users.length === 0) ? (
          <div className="text-center text-muted-foreground">
            No results found for "{query}"
          </div>
        ) : (
          <Tabs defaultValue="videos" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="videos">
                Videos ({results?.videos.length || 0})
              </TabsTrigger>
              <TabsTrigger value="users">
                Users ({results?.users.length || 0})
              </TabsTrigger>
            </TabsList>

            {/* Videos Tab */}
            <TabsContent value="videos" className="space-y-4">
              {results?.videos.map((video) => (
                <Card key={video.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-3">
                    <h3 className="font-semibold text-lg">{video.title}</h3>
                    <p className="text-sm text-muted-foreground">
                      {new Date(video.createdAt).toLocaleDateString()}
                    </p>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {video.description && (
                      <p className="text-sm text-foreground line-clamp-2">
                        {video.description}
                      </p>
                    )}
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Eye className="w-4 h-4" />
                        <span>{video.views} views</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Heart className="w-4 h-4" />
                        <span>{video.likes} likes</span>
                      </div>
                    </div>
                    <Button variant="outline" className="w-full">
                      Watch Video
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>

            {/* Users Tab */}
            <TabsContent value="users" className="space-y-4">
              {results?.users.map((user) => (
                <Card key={user.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-semibold">{user.name || "Anonymous User"}</h3>
                        <p className="text-sm text-muted-foreground">{user.email}</p>
                      </div>
                      <Button variant="outline">View Profile</Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>
          </Tabs>
        )}
      </div>
    </div>
  );
}
