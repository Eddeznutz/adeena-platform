import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";
import { Video, MessageCircle, Search, Users, Zap, Shield } from "lucide-react";

export default function Home() {
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen flex flex-col">
      <section className="py-20 px-4 bg-gradient-to-br from-orange-50 to-lime-50 dark:from-orange-950 dark:to-lime-950">
        <div className="container max-w-4xl mx-auto text-center space-y-6">
          <h1 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-orange-600 to-lime-500 bg-clip-text text-transparent">
            Welcome to Adeena
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Share your moments, connect with creators, and discover amazing content. Your private, encrypted social platform.
          </p>
          {!isAuthenticated ? (
            <Button
              size="lg"
              onClick={() => (window.location.href = getLoginUrl())}
              className="bg-gradient-to-r from-orange-600 to-lime-500 hover:from-orange-700 hover:to-lime-600"
            >
              Get Started
            </Button>
          ) : (
            <Button
              size="lg"
              onClick={() => setLocation("/feed")}
              className="bg-gradient-to-r from-orange-600 to-lime-500 hover:from-orange-700 hover:to-lime-600"
            >
              Go to Feed
            </Button>
          )}
        </div>
      </section>

      <section className="py-16 px-4">
        <div className="container max-w-5xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Features</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Video className="w-5 h-5 text-orange-600" />
                  Video Sharing
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Upload and share your videos with the world. Get likes, comments, and grow your audience.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="w-5 h-5 text-pink-600" />
                  Encrypted Messaging
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Send private, encrypted messages to connect with other creators and friends securely.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Search className="w-5 h-5 text-orange-600" />
                  Powerful Search
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Discover videos, users, and content with our advanced search functionality.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5 text-pink-600" />
                  Community
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Follow creators, engage with content, and build your community on Adeena.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="w-5 h-5 text-orange-600" />
                  Lightning Fast
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Experience blazing-fast performance with our optimized platform.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageCircle className="w-5 h-5 text-pink-600" />
                  Engagement
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Like, comment, and share to engage with the community and support creators.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section className="py-16 px-4 bg-muted">
        <div className="container max-w-2xl mx-auto text-center space-y-6">
          <h2 className="text-3xl font-bold">Ready to Join Adeena?</h2>
          <p className="text-muted-foreground">
            Start sharing your videos and connecting with creators today.
          </p>
          {!isAuthenticated ? (
            <Button
              size="lg"
              onClick={() => (window.location.href = getLoginUrl())}
              className="bg-gradient-to-r from-orange-600 to-lime-500 hover:from-orange-700 hover:to-lime-600"
            >
              Sign Up Now
            </Button>
          ) : (
            <Button
              size="lg"
              onClick={() => setLocation("/upload")}
              className="bg-gradient-to-r from-orange-600 to-lime-500 hover:from-orange-700 hover:to-lime-600"
            >
              Upload Your First Video
            </Button>
          )}
        </div>
      </section>
    </div>
  );
}
