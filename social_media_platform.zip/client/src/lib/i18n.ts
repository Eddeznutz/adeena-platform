/**
 * Internationalization (i18n) Configuration
 * Supports 50+ languages and regional localization
 */

export type Language =
  | "en" | "es" | "fr" | "de" | "it" | "pt" | "ru" | "ja" | "zh" | "ko"
  | "ar" | "hi" | "bn" | "pa" | "te" | "mr" | "ta" | "gu" | "kn" | "ml"
  | "th" | "vi" | "id" | "ms" | "tl" | "tr" | "pl" | "uk" | "cs" | "ro"
  | "el" | "he" | "fa" | "ur" | "sw" | "am" | "af" | "nl" | "sv" | "da"
  | "no" | "fi" | "hu" | "sk" | "sl" | "hr" | "sr" | "bg" | "mk" | "et"
  | "lv" | "lt" | "sq" | "hy" | "ka" | "eu" | "gl" | "ca" | "cy";

export const SUPPORTED_LANGUAGES: Record<Language, { name: string; nativeName: string; rtl?: boolean }> = {
  en: { name: "English", nativeName: "English" },
  es: { name: "Spanish", nativeName: "Español" },
  fr: { name: "French", nativeName: "Français" },
  de: { name: "German", nativeName: "Deutsch" },
  it: { name: "Italian", nativeName: "Italiano" },
  pt: { name: "Portuguese", nativeName: "Português" },
  ru: { name: "Russian", nativeName: "Русский" },
  ja: { name: "Japanese", nativeName: "日本語" },
  zh: { name: "Chinese (Simplified)", nativeName: "简体中文" },
  ko: { name: "Korean", nativeName: "한국어" },
  ar: { name: "Arabic", nativeName: "العربية", rtl: true },
  hi: { name: "Hindi", nativeName: "हिन्दी" },
  bn: { name: "Bengali", nativeName: "বাংলা" },
  pa: { name: "Punjabi", nativeName: "ਪੰਜਾਬੀ" },
  te: { name: "Telugu", nativeName: "తెలుగు" },
  mr: { name: "Marathi", nativeName: "मराठी" },
  ta: { name: "Tamil", nativeName: "தமிழ்" },
  gu: { name: "Gujarati", nativeName: "ગુજરાતી" },
  kn: { name: "Kannada", nativeName: "ಕನ್ನಡ" },
  ml: { name: "Malayalam", nativeName: "മലയാളം" },
  th: { name: "Thai", nativeName: "ไทย" },
  vi: { name: "Vietnamese", nativeName: "Tiếng Việt" },
  id: { name: "Indonesian", nativeName: "Bahasa Indonesia" },
  ms: { name: "Malay", nativeName: "Bahasa Melayu" },
  tl: { name: "Tagalog", nativeName: "Tagalog" },
  tr: { name: "Turkish", nativeName: "Türkçe" },
  pl: { name: "Polish", nativeName: "Polski" },
  uk: { name: "Ukrainian", nativeName: "Українська" },
  cs: { name: "Czech", nativeName: "Čeština" },
  ro: { name: "Romanian", nativeName: "Română" },
  el: { name: "Greek", nativeName: "Ελληνικά" },
  he: { name: "Hebrew", nativeName: "עברית", rtl: true },
  fa: { name: "Persian", nativeName: "فارسی", rtl: true },
  ur: { name: "Urdu", nativeName: "اردو", rtl: true },
  sw: { name: "Swahili", nativeName: "Kiswahili" },
  am: { name: "Amharic", nativeName: "አማርኛ" },
  af: { name: "Afrikaans", nativeName: "Afrikaans" },
  nl: { name: "Dutch", nativeName: "Nederlands" },
  sv: { name: "Swedish", nativeName: "Svenska" },
  da: { name: "Danish", nativeName: "Dansk" },
  no: { name: "Norwegian", nativeName: "Norsk" },
  fi: { name: "Finnish", nativeName: "Suomi" },
  hu: { name: "Hungarian", nativeName: "Magyar" },
  sk: { name: "Slovak", nativeName: "Slovenčina" },
  sl: { name: "Slovenian", nativeName: "Slovenščina" },
  hr: { name: "Croatian", nativeName: "Hrvatski" },
  sr: { name: "Serbian", nativeName: "Српски" },
  bg: { name: "Bulgarian", nativeName: "Български" },
  mk: { name: "Macedonian", nativeName: "Македонски" },
  et: { name: "Estonian", nativeName: "Eesti" },
  lv: { name: "Latvian", nativeName: "Latviešu" },
  lt: { name: "Lithuanian", nativeName: "Lietuvių" },
  sq: { name: "Albanian", nativeName: "Shqip" },
  hy: { name: "Armenian", nativeName: "Հայերեն" },
  ka: { name: "Georgian", nativeName: "ქართული" },
  eu: { name: "Basque", nativeName: "Euskara" },
  gl: { name: "Galician", nativeName: "Galego" },
  ca: { name: "Catalan", nativeName: "Català" },
  cy: { name: "Welsh", nativeName: "Cymraeg" },
};

export const DEFAULT_LANGUAGE: Language = "en";

/**
 * Get browser's preferred language
 */
export function getBrowserLanguage(): Language {
  const browserLang = navigator.language.split("-")[0].toLowerCase();
  return (browserLang in SUPPORTED_LANGUAGES) ? (browserLang as Language) : DEFAULT_LANGUAGE;
}

/**
 * Check if language is right-to-left
 */
export function isRTL(language: Language): boolean {
  return SUPPORTED_LANGUAGES[language]?.rtl ?? false;
}

/**
 * Format currency for locale
 */
export function formatCurrency(amount: number, language: Language, currency: string = "USD"): string {
  const locale = getLocaleString(language);
  return new Intl.NumberFormat(locale, {
    style: "currency",
    currency,
  }).format(amount);
}

/**
 * Format date for locale
 */
export function formatDate(date: Date, language: Language, options?: Intl.DateTimeFormatOptions): string {
  const locale = getLocaleString(language);
  return new Intl.DateTimeFormat(locale, options).format(date);
}

/**
 * Format number for locale
 */
export function formatNumber(num: number, language: Language): string {
  const locale = getLocaleString(language);
  return new Intl.NumberFormat(locale).format(num);
}

/**
 * Get locale string from language code
 */
function getLocaleString(language: Language): string {
  const localeMap: Record<Language, string> = {
    en: "en-US",
    es: "es-ES",
    fr: "fr-FR",
    de: "de-DE",
    it: "it-IT",
    pt: "pt-PT",
    ru: "ru-RU",
    ja: "ja-JP",
    zh: "zh-CN",
    ko: "ko-KR",
    ar: "ar-SA",
    hi: "hi-IN",
    bn: "bn-IN",
    pa: "pa-IN",
    te: "te-IN",
    mr: "mr-IN",
    ta: "ta-IN",
    gu: "gu-IN",
    kn: "kn-IN",
    ml: "ml-IN",
    th: "th-TH",
    vi: "vi-VN",
    id: "id-ID",
    ms: "ms-MY",
    tl: "tl-PH",
    tr: "tr-TR",
    pl: "pl-PL",
    uk: "uk-UA",
    cs: "cs-CZ",
    ro: "ro-RO",
    el: "el-GR",
    he: "he-IL",
    fa: "fa-IR",
    ur: "ur-PK",
    sw: "sw-KE",
    am: "am-ET",
    af: "af-ZA",
    nl: "nl-NL",
    sv: "sv-SE",
    da: "da-DK",
    no: "nb-NO",
    fi: "fi-FI",
    hu: "hu-HU",
    sk: "sk-SK",
    sl: "sl-SI",
    hr: "hr-HR",
    sr: "sr-RS",
    bg: "bg-BG",
    mk: "mk-MK",
    et: "et-EE",
    lv: "lv-LV",
    lt: "lt-LT",
    sq: "sq-AL",
    hy: "hy-AM",
    ka: "ka-GE",
    eu: "eu-ES",
    gl: "gl-ES",
    ca: "ca-ES",
    cy: "cy-GB",
  };
  return localeMap[language] || "en-US";
}

/**
 * Translations object type
 */
export interface Translations {
  [key: string]: string | Translations;
}

/**
 * Get translation with fallback
 */
export function getTranslation(
  translations: Translations,
  key: string,
  language: Language,
  defaultLanguage: Language = DEFAULT_LANGUAGE
): string {
  const keys = key.split(".");
  let current: any = translations;

  for (const k of keys) {
    if (current[k] === undefined) {
      return key; // Return key if translation not found
    }
    current = current[k];
  }

  return typeof current === "string" ? current : key;
}
