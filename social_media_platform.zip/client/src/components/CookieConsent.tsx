import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";

/**
 * Cookie Consent Banner
 * GDPR/CCPA compliant cookie consent management
 */
export default function CookieConsent() {
  const [isVisible, setIsVisible] = useState(false);
  const [showDetails, setShowDetails] = useState(false);

  useEffect(() => {
    // Check if user has already made a choice
    const consent = localStorage.getItem("cookie-consent");
    if (!consent) {
      setIsVisible(true);
    }
  }, []);

  const handleAcceptAll = () => {
    localStorage.setItem("cookie-consent", JSON.stringify({
      essential: true,
      analytics: true,
      marketing: true,
      timestamp: new Date().toISOString(),
    }));
    setIsVisible(false);
    // Load analytics and marketing scripts
    loadAnalytics();
    loadMarketing();
  };

  const handleRejectAll = () => {
    localStorage.setItem("cookie-consent", JSON.stringify({
      essential: true,
      analytics: false,
      marketing: false,
      timestamp: new Date().toISOString(),
    }));
    setIsVisible(false);
  };

  const handleCustom = (analytics: boolean, marketing: boolean) => {
    localStorage.setItem("cookie-consent", JSON.stringify({
      essential: true,
      analytics,
      marketing,
      timestamp: new Date().toISOString(),
    }));
    setIsVisible(false);
    if (analytics) loadAnalytics();
    if (marketing) loadMarketing();
  };

  const loadAnalytics = () => {
    // Load analytics script (e.g., Google Analytics, Umami)
    console.log("Loading analytics...");
  };

  const loadMarketing = () => {
    // Load marketing/advertising scripts
    console.log("Loading marketing scripts...");
  };

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-gray-200 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 py-6">
        {!showDetails ? (
          <div className="flex items-center justify-between gap-4">
            <div className="flex-1">
              <h3 className="font-semibold text-gray-900 mb-2">
                Cookie Preferences
              </h3>
              <p className="text-sm text-gray-600">
                We use cookies to enhance your experience, analyze site traffic, and serve personalized content. 
                By clicking "Accept All", you consent to our use of cookies. You can customize your preferences.
              </p>
            </div>
            <div className="flex gap-2 flex-shrink-0">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowDetails(true)}
              >
                Customize
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handleRejectAll}
              >
                Reject All
              </Button>
              <Button
                size="sm"
                onClick={handleAcceptAll}
              >
                Accept All
              </Button>
              <button
                onClick={() => setIsVisible(false)}
                className="p-1 hover:bg-gray-100 rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        ) : (
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-gray-900">
                Cookie Settings
              </h3>
              <button
                onClick={() => setShowDetails(false)}
                className="p-1 hover:bg-gray-100 rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-4 mb-6">
              {/* Essential Cookies */}
              <div className="flex items-start gap-3">
                <input
                  type="checkbox"
                  id="essential"
                  checked
                  disabled
                  className="mt-1"
                />
                <div className="flex-1">
                  <label htmlFor="essential" className="font-medium text-gray-900">
                    Essential Cookies (Required)
                  </label>
                  <p className="text-sm text-gray-600">
                    Necessary for core functionality like authentication, security, and site stability.
                  </p>
                </div>
              </div>

              {/* Analytics Cookies */}
              <div className="flex items-start gap-3">
                <input
                  type="checkbox"
                  id="analytics"
                  defaultChecked
                  className="mt-1"
                />
                <div className="flex-1">
                  <label htmlFor="analytics" className="font-medium text-gray-900">
                    Analytics Cookies
                  </label>
                  <p className="text-sm text-gray-600">
                    Help us understand how you use Adeena to improve our service and user experience.
                  </p>
                </div>
              </div>

              {/* Marketing Cookies */}
              <div className="flex items-start gap-3">
                <input
                  type="checkbox"
                  id="marketing"
                  defaultChecked
                  className="mt-1"
                />
                <div className="flex-1">
                  <label htmlFor="marketing" className="font-medium text-gray-900">
                    Marketing Cookies
                  </label>
                  <p className="text-sm text-gray-600">
                    Used to deliver personalized advertisements and track marketing effectiveness.
                  </p>
                </div>
              </div>
            </div>

            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={handleRejectAll}
              >
                Reject All
              </Button>
              <Button
                onClick={() => {
                  const analytics = (document.getElementById("analytics") as HTMLInputElement)?.checked ?? false;
                  const marketing = (document.getElementById("marketing") as HTMLInputElement)?.checked ?? false;
                  handleCustom(analytics, marketing);
                  setShowDetails(false);
                }}
              >
                Save Preferences
              </Button>
              <Button
                onClick={handleAcceptAll}
              >
                Accept All
              </Button>
            </div>

            <p className="text-xs text-gray-500 mt-4">
              <a href="/legal/privacy" className="underline hover:text-gray-700">
                Privacy Policy
              </a>
              {" • "}
              <a href="/legal/cookies" className="underline hover:text-gray-700">
                Cookie Policy
              </a>
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
