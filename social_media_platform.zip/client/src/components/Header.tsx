import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useLocation } from "wouter";
import { Search, MessageCircle, Upload, Home, User, LogOut, Globe } from "lucide-react";
import { useState } from "react";
import { getLoginUrl } from "@/const";

export default function Header() {
  const { user, logout, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [webSearchQuery, setWebSearchQuery] = useState("");

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setLocation(`/search?q=${encodeURIComponent(searchQuery)}`);
      setSearchQuery("");
    }
  };

  const handleWebSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (webSearchQuery.trim()) {
      window.open(`https://duckduckgo.com/?q=${encodeURIComponent(webSearchQuery)}`, '_blank');
      setWebSearchQuery("");
    }
  };

  const handleLogout = async () => {
    await logout();
    setLocation("/");
  };

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between gap-4">
        {/* Logo */}
        <div className="flex items-center gap-2 cursor-pointer" onClick={() => setLocation("/")}>
          <div className="w-8 h-8 bg-gradient-to-br from-orange-600 to-lime-400 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-sm">A</span>
          </div>
          <span className="font-bold text-lg hidden sm:inline">Adeena</span>
        </div>

        {/* Dual Search Bars */}
        <div className="flex-1 flex gap-2 max-w-2xl hidden md:flex">
          {/* Adeena Platform Search */}
          <form onSubmit={handleSearch} className="flex-1">
            <div className="relative w-full">
              <Input
                type="text"
                placeholder="Search Adeena..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            </div>
          </form>

          {/* DuckDuckGo Web Search */}
          <form onSubmit={handleWebSearch} className="flex-1">
            <div className="relative w-full">
              <Input
                type="text"
                placeholder="Search Web (DuckDuckGo)..."
                value={webSearchQuery}
                onChange={(e) => setWebSearchQuery(e.target.value)}
                className="pl-10 pr-4 border-lime-300 focus:border-lime-500"
              />
              <Globe className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-lime-500" />
            </div>
          </form>
        </div>

        {/* Navigation */}
        <nav className="flex items-center gap-2">
          {isAuthenticated ? (
            <>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setLocation("/feed")}
                title="Feed"
              >
                <Home className="w-5 h-5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setLocation("/upload")}
                title="Upload Video"
              >
                <Upload className="w-5 h-5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setLocation("/messages")}
                title="Messages"
              >
                <MessageCircle className="w-5 h-5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setLocation("/profile")}
                title="Profile"
              >
                <User className="w-5 h-5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={handleLogout}
                title="Logout"
              >
                <LogOut className="w-5 h-5" />
              </Button>
            </>
          ) : (
            <Button onClick={() => (window.location.href = getLoginUrl())}>
              Sign In
            </Button>
          )}
        </nav>
      </div>
    </header>
  );
}
