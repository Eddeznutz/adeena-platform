# Adeena - Free Deployment Guide

This guide will help you deploy Adeena to free hosting platforms permanently.

## Prerequisites

Before deploying, you'll need:
- GitHub account (free)
- Account on your chosen hosting platform (free)
- Your code exported from Manus

## Step 1: Export Your Code

1. In the Manus Management UI, go to **Code** tab
2. Click **Download All Files** button
3. Save the ZIP file to your computer
4. Extract the ZIP file

## Step 2: Push to GitHub

1. Go to https://github.com and sign in
2. Click **New Repository**
3. Name it `adeena-platform`
4. Make it **Public** (required for free hosting)
5. Click **Create Repository**

6. Open terminal/command prompt in your extracted folder
7. Run these commands:

```bash
git init
git add .
git commit -m "Initial commit - Adeena platform"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/adeena-platform.git
git push -u origin main
```

## Option A: Deploy to Railway (Recommended)

**Why Railway:**
- Supports full-stack apps with databases
- Free tier: 500 hours/month
- Easy setup
- Automatic HTTPS

**Steps:**

1. Go to https://railway.app
2. Click **Start a New Project**
3. Click **Deploy from GitHub repo**
4. Select your `adeena-platform` repository
5. Railway will auto-detect the project

6. **Add Database:**
   - Click **New** → **Database** → **Add MySQL**
   - Railway will create a database and set `DATABASE_URL` automatically

7. **Set Environment Variables:**
   Click on your service → **Variables** tab → Add these:

   ```
   NODE_ENV=production
   JWT_SECRET=your-super-secret-jwt-key-change-this
   OAUTH_SERVER_URL=https://api.manus.im
   VITE_APP_ID=your-app-id
   VITE_OAUTH_PORTAL_URL=https://login.manus.im
   ```

8. **Deploy:**
   - Railway will automatically build and deploy
   - Wait 3-5 minutes for deployment
   - You'll get a URL like `adeena-platform.up.railway.app`

9. **Custom Domain (Optional):**
   - Click **Settings** → **Domains**
   - Add your custom domain or use Railway's free subdomain

## Option B: Deploy to Render

**Why Render:**
- Free tier includes web services + databases
- Easy to use
- Automatic SSL

**Steps:**

1. Go to https://render.com
2. Click **Get Started for Free**
3. Connect your GitHub account

4. **Create Database:**
   - Click **New** → **MySQL**
   - Name: `adeena-db`
   - Free tier
   - Click **Create Database**
   - Copy the **Internal Database URL**

5. **Create Web Service:**
   - Click **New** → **Web Service**
   - Connect your `adeena-platform` repo
   - Name: `adeena`
   - Environment: **Node**
   - Build Command: `pnpm install && pnpm build`
   - Start Command: `pnpm start`
   - Free tier

6. **Add Environment Variables:**
   Scroll to **Environment Variables** and add:

   ```
   NODE_ENV=production
   DATABASE_URL=<paste Internal Database URL from step 4>
   JWT_SECRET=your-super-secret-jwt-key-change-this
   OAUTH_SERVER_URL=https://api.manus.im
   VITE_APP_ID=your-app-id
   VITE_OAUTH_PORTAL_URL=https://login.manus.im
   ```

7. **Deploy:**
   - Click **Create Web Service**
   - Wait 5-10 minutes for deployment
   - You'll get a URL like `adeena.onrender.com`

## Option C: Deploy to Vercel (Frontend Only)

**Note:** Vercel is best for frontend-only apps. For Adeena's full-stack features, use Railway or Render instead.

If you still want to try Vercel:

1. Go to https://vercel.com
2. Click **Import Project**
3. Import from GitHub
4. Select `adeena-platform`
5. Vercel will auto-detect and deploy
6. You'll need a separate backend hosting for the API

## Step 3: Configure OAuth (Important!)

Since Adeena uses Manus OAuth for authentication, you'll need to either:

**Option 1: Keep Manus OAuth**
- Contact Manus support to whitelist your new domain
- Update `OAUTH_SERVER_URL` and `VITE_OAUTH_PORTAL_URL`

**Option 2: Switch to Different Auth**
- Implement Google OAuth, GitHub OAuth, or email/password
- Update authentication code in `server/_core/auth.ts`

## Step 4: Set Up Database

1. Your hosting platform will provide a MySQL database
2. Copy the `DATABASE_URL` connection string
3. Add it to environment variables
4. Run migrations:

```bash
pnpm db:push
```

## Step 5: Test Your Deployment

1. Visit your deployed URL
2. Test key features:
   - Homepage loads
   - Can sign up/login
   - Can upload videos
   - Can send messages
   - Search works

## Troubleshooting

**Build Fails:**
- Check build logs for errors
- Ensure all dependencies are in `package.json`
- Verify Node version (should be 22.x)

**Database Connection Fails:**
- Verify `DATABASE_URL` is correct
- Check database is running
- Ensure SSL is enabled if required

**OAuth Doesn't Work:**
- Verify OAuth URLs are correct
- Check domain is whitelisted
- Consider switching to email/password auth

## Cost Estimates

**Free Tiers:**
- Railway: 500 hours/month (enough for 24/7 with one service)
- Render: 750 hours/month
- Vercel: Unlimited for hobby projects

**When You Outgrow Free:**
- Railway: ~$5-20/month
- Render: ~$7-25/month
- Vercel: ~$20/month

## Next Steps After Deployment

1. **Set up custom domain** (optional, ~$10-15/year)
2. **Configure CDN** for faster video/music delivery
3. **Set up monitoring** (UptimeRobot is free)
4. **Add analytics** (Google Analytics is free)
5. **Submit to Google Search Console** for SEO

## Need Help?

- Railway Docs: https://docs.railway.app
- Render Docs: https://render.com/docs
- Vercel Docs: https://vercel.com/docs

---

**Your Adeena platform is ready to deploy! Choose your preferred hosting platform and follow the steps above. Good luck! 🚀**
